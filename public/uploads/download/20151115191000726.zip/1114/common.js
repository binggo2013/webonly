/**
 * Created by Administrator on 15-11-1.
 */
function $(_id){
    return document.getElementById(_id);
}
/**
 * ΪС��10���������0
 * @return {string}
 * */
function addZero(_num){
    if(_num<10){
        _num="0"+_num;
    }else{
        _num=""+_num;
    }
    return _num;
}
/**
 * ���ݶ��������Ĵ��ڵĳߴ�
 * */
function getWindowSize(){
    return {
        width:document.documentElement.clientWidth||window.innerWidth,
        height:document.documentElement.clientHeight||window.innerHeight
    }
}
/**
 * ���ݶ��������Ĺ������ĳߴ�
 * @todo ie8
 * */
function getScrollSize(){
    return {
        left:document.documentElement.scrollLeft||document.body.scrollLeft,
        top:document.documentElement.scrollTop||document.body.scrollTop
    }
}
/**
 * 根据元素的类名称选择元素
 * 循环所有的元素，符合指定类名称的元素追加到空数组中
 * 不符合的忽略。
 * */
function getElementsByClassName(_element,_className){
    var arr=[];
    for(var i=0;i<_element.length;i++){
        //如果元素的className等于传进来的_className
        if(_element[i].className==_className){
            arr.push(_element[i]);
        }else{
            continue;
        }
    }
    return arr;
}
/**
 * 多个页面多次执行window.onload
 * */
function addLoadEvent(func){
    var oldload=window.onload;
    if(typeof window.onload!='function'){
        window.onload=func;
    }else{
        window.onload=function(){
            oldload();
            func();
        }
    }
}