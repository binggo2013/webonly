<?php
class autoloader{
	public static $loader;
	/**
	 * 初始化方法(单例模式)
	 * @return autoloader  */
	public static function init(){
		if(self::$loader==null){
			self::$loader=new self();
		}
		return self::$loader;
	}
	//构造方法
	public function __construct(){
		spl_autoload_register(array($this,'autoloader'));
	}
	//自动加载
	public function autoloader($classname){
		//设置包含路径
		set_include_path(get_include_path().PATH_SEPARATOR.'/includes');
		//加载文件扩展
		spl_autoload_extensions(".class.php");
		spl_autoload($classname);
	}
}
////////////////////
//indexAction.class.php
//indexModel.class.php
?>