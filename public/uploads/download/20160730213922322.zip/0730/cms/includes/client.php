<?php
include 'Image.class.php';
$image=new Image();
$image->waterMark("sun.jpg", "logo.png",1);
?>