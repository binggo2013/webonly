<?php
include 'Captcha.class.php';
$captcha=new Captcha();
$captcha->setConfig(array('level'=>20,"isNoise"=>true,'simple'=>false));
$captcha->showCaptcha();
?>