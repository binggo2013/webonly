<?php
class Bmodel{
	private $color;
	private $name;
	public function __construct(){
		echo "constructor222,";
	}
	public function msg(){
		echo "b";
	}
}
?>