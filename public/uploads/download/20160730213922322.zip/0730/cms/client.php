<?php
function autoloader($_className){
	echo substr($_className, -5)."<br>";
	if(substr($_className, -5)=='model'){
		include "model/".$_className.'.class.php';
	}else if(substr($_className, -6)=='action'){
		include "controller/".$_className.'.class.php';
	}else{
		include "includes//".$_className.'.class.php';
	}
}
spl_autoload_register('autoloader');
$image=new Image();
$image->waterMark("sun.jpg","logo.jpg");
if(isset($_POST['send'])){
	//var_dump($_FILES);
	$transfer=new M_Transfer(array("fieldName"=>"pic","path"=>'uploads/ads/banner'));
	$transfer->upload("pic");
	$transfer->getError();
}
?>
<form action='' method="post" enctype="multipart/form-data">
	<input type='file' name="pic[]" multiple><br>
	<input type="submit" name="send">
</form>