<?php
include "autoloader.php";
autoloader::init();
$a=new A();
$a->msg();
//$captcha=new Captcha();
//var_dump($captcha);
//Tools::dump("hello");
/* function autoloader(){
	//设置包含路径
	set_include_path(get_include_path().PATH_SEPARATOR.'/includes');
	//加载文件扩展
	spl_autoload_extensions(".class.php");
	spl_autoload($classname);
}
spl_autoload_register(array($this,'autoloader'));
//实例化A时
$a=new A();
$a->msg();
echo "<hr>";
$b=new B();
$b->msg();
echo '<hr>';
//echo "c:/nba/b/c";
set_include_path(get_include_path().PATH_SEPARATOR.'/includes');
echo get_include_path();
Tools::dump($a); */
/**
 * include|include_once
 * require|require_once;
 *   */
/* include 'A.class.php';
include 'B.class.php';
$a=new A();
$a->msg();
echo "<hr>";
$b=new B();
$b->msg(); */
?>