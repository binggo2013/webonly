-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- 主机: 127.0.0.1
-- 生成日期: 2016 年 07 月 30 日 11:34
-- 服务器版本: 5.5.27
-- PHP 版本: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `kong`
--
DROP DATABASE `kong`;
CREATE DATABASE `kong` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `kong`;

-- --------------------------------------------------------

--
-- 表的结构 `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) NOT NULL,
  `username` int(11) NOT NULL,
  `pwd` int(11) NOT NULL,
  `email` int(11) NOT NULL,
  `regTime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productName` varchar(150) NOT NULL,
  `price` int(11) NOT NULL,
  `cover` varchar(150) NOT NULL,
  `amount` int(11) NOT NULL,
  `pTime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `product`
--

INSERT INTO `product` (`id`, `productName`, `price`, `cover`, `amount`, `pTime`) VALUES
(1, 'HTML', 50, 'html.jpg', 100, '2016-07-30 02:14:13'),
(2, 'CSS', 55, 'css.jpg', 100, '2016-07-30 02:15:06'),
(3, 'javascript', 150, 'js.jpg', 100, '2016-07-30 03:23:05'),
(4, 'jquery', 55, 'jquery.jpg', 100, '2016-07-30 01:07:02'),
(5, 'PHP(I)', 55, 'p1.jpg', 100, '2016-07-30 01:09:04'),
(6, 'PHP(II)', 55, 'p2.jpg', 100, '2016-07-30 02:06:07');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` int(11) NOT NULL,
  `pwd` int(11) NOT NULL,
  `email` int(11) NOT NULL,
  `regTime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
