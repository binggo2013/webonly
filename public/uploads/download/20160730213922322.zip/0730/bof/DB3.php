<?php
/*没有使用设计模式  */
class DB{
	private $db;
	public function __construct(){
		try{
			$this->db=new PDO("mysql:host=localhost;dbname=kong","root","");
			echo "one database object<br>";
		}catch(PDOException $e){
			exit($e->getMessage());
		}
	}
	public function Article($_sql){
		return $this->db->query($_sql);
	}
} 
abstract class Action{
	protected $db;
	public function __construct(){
		global $a;
		$this->db=$a;
	}
	abstract public function query($_sql);
}
class User extends Action{
	public function query($_sql){
		return $this->db->query($_sql);
	}
}
class Article extends Action{
	public function query($_sql){
		return $this->db->query($_sql);
	}
}
$a=new DB();
var_dump($a);
$user=new User();
$article=new Article();
echo "<pre>";
var_dump($user->query("select * from user"));
var_dump($article->query("select * from article"));
echo "</pre>";
?>