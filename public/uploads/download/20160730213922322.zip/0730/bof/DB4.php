<?php
/*单例模式  */
class DB{
	static private $instance;
	public static function getInstance(){
		//$instance instanceof self
		//如果instance属性不是类的实例的话
		if(!self::$instance instanceof self){
			self::$instance=new self();
		}
		return self::$instance;
	}
	public function __construct(){
		try{
			$this->db=new PDO("mysql:host=localhost;dbname=kong","root","");
			echo "one database object<br>";
		}catch(PDOException $e){
			exit($e->getMessage());
		}
	}
	public function query($_sql){
		return $this->db->query($_sql);
	}
} 
abstract class Action{
	protected $db;
	public function __construct(){
		$this->db=DB::getInstance();
	}
	abstract public function query($_sql);
}
class User extends Action{
	public function query($_sql){
		return $this->db->query($_sql);
	}
}
class Article extends Action{
	public function query($_sql){
		return $this->db->query($_sql);
	}
}
class Comment extends Action{
	public function query($_sql){
		return $this->db->query($_sql);
	}
}

$user=new User();
$article=new Article();
$c=new Comment();
echo "<pre>";
var_dump($c->query("select * from user"));
var_dump($user->query("select * from user"));
var_dump($article->query("select * from article"));
echo "</pre>";
?>