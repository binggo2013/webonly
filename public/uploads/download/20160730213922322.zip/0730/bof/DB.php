<?php
/*没有使用设计模式  */
class DB{
	private $db;
	public function __construct(){
		try{
			$this->db=new PDO("mysql:host=localhost;dbname=kong","root","");
			echo "one database object";
		}catch(PDOException $e){
			exit($e->getMessage());
		}
	}
	public function query($_sql){
		return $this->db->query($_sql);
	}
}
$db=new DB();
var_dump($db->query("select * from user"));
var_dump($db->query("select * from user"));
var_dump($db->query("select * from user"));
?>