<?php
include '../../../Smarty.init.php';
$pdo=new PDO("mysql:host=localhost;dbname=kong",'root','');
$result=$pdo->query("select * from product order by id desc");
$data=$result->fetchAll(PDO::FETCH_OBJ);
//echo "<pre>";
//var_dump($data);
//echo "</pre>";
//var_dump($smarty);
if($_GET['action']=="detail"){
	$smarty->assign("all",false);
	$smarty->assign("one",true);
	$result2=$pdo->query("select * from product where id=".$_GET['id']);
	$oneProduct=$result2->fetch(PDO::FETCH_OBJ);
	//var_dump($oneProduct);
	$smarty->assign("oneProduct",$oneProduct);
}else{
	$smarty->assign("data",$data);
	$smarty->assign("all",true);
	$smarty->assign("one",false);
}
$smarty->display("home/home.html");
?>