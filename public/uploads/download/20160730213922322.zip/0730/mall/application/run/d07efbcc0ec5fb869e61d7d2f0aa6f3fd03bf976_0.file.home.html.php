<?php
/* Smarty version 3.1.29, created on 2016-07-30 11:27:53
  from "C:\xampp\htdocs\php2\mall\application\views\home\home.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_579c7319da5246_94036525',
  'file_dependency' => 
  array (
    'd07efbcc0ec5fb869e61d7d2f0aa6f3fd03bf976' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php2\\mall\\application\\views\\home\\home.html',
      1 => 1469870870,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_579c7319da5246_94036525 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<style>
.main{
	border:1px solid #ddd;
	width:900px;
	margin:auto;
}
.main ul,.detail{
	list-style:none;
	border:1px solid red;
	display:inline-block;
}
.main ul li,.detail li{
	display:block;
}

.oneProduct{
	width:100px;
	height:200px;
}
</style>
</head>
<body>
<?php if ($_smarty_tpl->tpl_vars['one']->value) {?>
<ul class='detail'>
	<li><?php echo $_smarty_tpl->tpl_vars['oneProduct']->value->productName;?>
</li>
	<li><a href="?action=detail&id=<?php echo $_smarty_tpl->tpl_vars['oneProduct']->value->id;?>
"><img src='../../../public/uploads/product/<?php echo $_smarty_tpl->tpl_vars['oneProduct']->value->cover;?>
' class='oneProduct'></a></li>
	<li><?php echo $_smarty_tpl->tpl_vars['oneProduct']->value->price;?>
&nbsp;&nbsp;&nbsp;<?php echo $_smarty_tpl->tpl_vars['oneProduct']->value->amount;?>
</li>
	<li><a href="?action=add&id=<?php echo $_smarty_tpl->tpl_vars['oneProduct']->value->id;?>
">放入购物车</a></li>
</ul>
<?php }
if ($_smarty_tpl->tpl_vars['all']->value) {?>
<div class="main">
<?php
$_from = $_smarty_tpl->tpl_vars['data']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_value_0_saved_item = isset($_smarty_tpl->tpl_vars['value']) ? $_smarty_tpl->tpl_vars['value'] : false;
$__foreach_value_0_saved_key = isset($_smarty_tpl->tpl_vars['key']) ? $_smarty_tpl->tpl_vars['key'] : false;
$_smarty_tpl->tpl_vars['value'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['key'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['value']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
$_smarty_tpl->tpl_vars['value']->_loop = true;
$__foreach_value_0_saved_local_item = $_smarty_tpl->tpl_vars['value'];
?>
<ul>
	<li><?php echo $_smarty_tpl->tpl_vars['value']->value->productName;?>
</li>
	<li><a href="?action=detail&id=<?php echo $_smarty_tpl->tpl_vars['value']->value->id;?>
"><img src='../../../public/uploads/product/<?php echo $_smarty_tpl->tpl_vars['value']->value->cover;?>
' class='oneProduct'></a></li>
	<li><?php echo $_smarty_tpl->tpl_vars['value']->value->price;?>
&nbsp;&nbsp;&nbsp;<?php echo $_smarty_tpl->tpl_vars['value']->value->amount;?>
</li>
	<li></li>
</ul>
<?php
$_smarty_tpl->tpl_vars['value'] = $__foreach_value_0_saved_local_item;
}
if ($__foreach_value_0_saved_item) {
$_smarty_tpl->tpl_vars['value'] = $__foreach_value_0_saved_item;
}
if ($__foreach_value_0_saved_key) {
$_smarty_tpl->tpl_vars['key'] = $__foreach_value_0_saved_key;
}
?>
</div>
<?php }?>
</body>
</html><?php }
}
