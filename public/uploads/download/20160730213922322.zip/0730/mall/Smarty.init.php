<?php
/*smarty初始化 */
session_start();
error_reporting(E_ALL);
//设置默认时区
define("ROOT",dirname(__FILE__));
//include ROOT."/includes/Tools.class.php";
//echo ROOT;
include ROOT."/libs/Smarty.class.php";
$smarty=new Smarty();
//var_dump($smarty);
//设置模板目录(前台文件)
$smarty->template_dir=ROOT.'/application/views';
//编译目录，随时可删除.
$smarty->compile_dir=ROOT.'/application/run';
?>