<?php
class A {
	private $color;
	private $name;
	public function __construct(){
		echo "constructor,";
	}
	public function msg(){
		echo "abbbb";
	}
}
?>