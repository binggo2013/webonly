setTimeout(function(){
    alert(1);
},2000)
