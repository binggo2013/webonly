<?php
    //var_dump���������
    //var_dump($_GET);
    var_dump($_GET['username']);
?>
<form action='post.php' method="get">
    <input type="text" placeholder='username' name='username'><br>
    <input type='submit' value='submit'>
</form>