<?php
    sleep(3);
    //var_dump($_POST);
    //echo $_POST['username'];
    if($_POST['username']=='admin'){
        echo "ok";
    }else{
        echo "failed";
    }
?>