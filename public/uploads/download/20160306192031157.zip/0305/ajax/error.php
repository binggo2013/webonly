<?php
	//错误处理
	error_reporting(E_ALL ^ E_STRICT ^E_NOTICE);
?>