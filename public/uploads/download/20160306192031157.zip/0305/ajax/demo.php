<?php   
	
    sleep(2);
    echo "[{'username':'tom'},{'gender':'female'}]";
?>