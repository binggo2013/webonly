<?php
sleep(3);
$con=mysql_connect("localhost","root","");
mysql_query("set names utf8");
mysql_select_db("only2");
//var_dump($_POST);
$sql="insert into user(username,pwd)values('".$_POST['username']."','".$_POST['pwd']."')";
$query=mysql_query($sql);
//var_dump($query);
if($query){
	echo "ok";
}else{
	echo "failed";
}
?>