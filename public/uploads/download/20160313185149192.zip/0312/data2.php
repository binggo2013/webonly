<?php
//�ӳٴ���ִ��ʱ��
sleep(3);
//echo name;
if($_POST['username']=="tom"){
     echo "ok";
 }else if($_POST['username']=="peter"){
    echo "failed";
 }
?>