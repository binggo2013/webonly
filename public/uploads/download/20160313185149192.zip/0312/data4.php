<?php
sleep(3);
$con=mysql_connect("localhost","root","");
mysql_query("set names utf8");
mysql_select_db("only2");
$query=mysql_query("select * from user");
//新建一空变量
$json=null;
while($data=mysql_fetch_array($query)){	
	$json.=json_encode($data).",";	
}
echo "[".rtrim($json,",")."]";
?>