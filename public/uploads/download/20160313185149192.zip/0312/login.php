<?php
sleep(3);
$con=mysql_connect("localhost","root","");
mysql_query("set names utf8");
mysql_select_db("only2");
//var_dump($_POST);
$query=mysql_query("select * from user where username='".$_POST['username']."' and pwd='".$_POST['pwd']."'");
//echo "select * from user where username='".$_POST['username']."' and pwd='".$_POST['pwd']."'";
$data=mysql_fetch_array($query);
//var_dump($data);
if($data){	
	echo "[".json_encode($data)."]";
}else{
	echo "failed";
} 
?>