<?php
sleep(1);
$con=mysql_connect("localhost","root","");
mysql_query("set names utf8");
mysql_select_db("only2");
//var_dump($_POST);
$sql="select * from sports limit 5";
//echo $sql; 
$query=mysql_query($sql);
$json="";
while($data=mysql_fetch_array($query)){
	//var_dump($data);
	$json.=json_encode($data).",";
}
echo "[".rtrim($json,",")."]";
?>