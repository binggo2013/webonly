<?php
//延迟代码执行3秒钟
sleep(3);
//连接mysql服务器
$con=mysql_connect("localhost","root","");
//设置操作数据库的字符集
mysql_query("set names utf8");
//选择数据库
mysql_select_db("only2");
//var_dump($_POST);
//查询语句
$sql="select * from user where username='".$_POST['username']."'";
//echo $sql;
//执行sql语句
$query=mysql_query($sql);
//从结果集中获取数据
$result=mysql_fetch_array($query);
//var_dump($result);
//如果查询到结果
if($result){
	echo "taken";
	//如果没有查询到结果在执行插入
}else{
	$sql2="insert into user(username,pwd)values('".$_POST['username']."','".$_POST['pwd']."')";
	$query2=mysql_query($sql2);
	//var_dump($query);
	if($query2){
		echo "ok";
	}else{
		echo "failed";
	}
}
?>