<?php
//sleep(3);
//链接mysql服务器
//主机：localhost，用户：root，密码为空;
$con=mysql_connect("localhost","root","");
//执行sql语句
mysql_query("set names utf8");
//var_dump($con);
//选择数据库
mysql_select_db("only2");
$query=mysql_query("select * from user");
//var_dump($query);
echo"<pre>";
var_dump(mysql_fetch_array($query));
echo"</pre>";
echo"<hr>";
$result=mysql_fetch_array($query);
echo $result['username'];
echo $result['pwd'];
?>