<?php 
	$str1="shanghai";
	$str2="beijing";
	echo $str1.$str2;
?>