<?php
    //sleep(3);
    mysql_connect("localhost","root","") or die("mysql sever has wrong");
    mysql_select_db("kong")or die("db has wrong");
    mysql_query("set names utf8");
    $sql="select * from user order by id desc limit 5";
    $query=mysql_query($sql);
    $json=null;
    while($data=mysql_fetch_array($query)){
        $json.=json_encode($data).",";
    }
    echo "[".rtrim($json,",")."]";
?>