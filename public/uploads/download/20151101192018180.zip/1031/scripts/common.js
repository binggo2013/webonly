/**
 * Created by Administrator on 15-11-1.
 */
function $(id){
    return document.getElementById(id);
}
