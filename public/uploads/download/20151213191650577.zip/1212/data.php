<?php
    sleep(3);
    //����mysql������
    mysql_connect("localhost","root","");
    //ѡ�����ݿ�
    mysql_select_db("only");
    //���ò������ݿ���ַ���
    mysql_query("set names utf8");
    //var_dump($_POST);
    //echo $_POST['num'];
    $sql=null;
    if($_POST['num']==0){
        $sql="select * from user order by id desc limit 5";
    }else if($_POST['num']==1){
        $sql="select * from search order by id desc limit 5";
    }else if($_POST['num']==2){
        $sql="select * from member order by id desc limit 5";
    }else{
        echo "wrong";
    }
    //echo $sql;
    $json=null;
    $result=mysql_query($sql);
    while($data=mysql_fetch_object($result)){
        $json.=json_encode($data).",";
    }
    $json=rtrim($json,",");
    echo "[".$json."]";
?>