<?php
    echo $_POST['username'];
?>