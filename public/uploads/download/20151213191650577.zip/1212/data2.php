<?php
    //var_dump($_POST);
    echo $_POST['username'].$_POST['gender'];
?>