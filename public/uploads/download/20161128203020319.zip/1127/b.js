setTimeout(function(){
    for(var i=0;i<10000000;i++){

    }
},5000)
console.log(2);