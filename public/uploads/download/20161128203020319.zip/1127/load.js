var img=document.querySelector("img");
console.log(img);
