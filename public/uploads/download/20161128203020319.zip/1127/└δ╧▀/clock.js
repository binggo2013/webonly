window.addEventListener('load',function(){
    document.querySelector("h1").innerHTML=new Date().toLocaleTimeString();
})