/*小于10的数字加0*/
function addZero(_number){
    if(_number<10){
        _number="0"+_number;
    }else{
        _number=""+_number;
    }
    return _number;
}
/*获取滚动条的尺寸*/
function getScrollSize(){
    return {
        "left":document.documentElement.scrollLeft||document.body.scrollLeft,
        "top":document.documentElement.scrollTop|document.body.scrollTop
    }
}
/*或窗口的尺寸*/
function getWindowSize() {
    return {
        "width": window.innerWidth || document.documentElement.clientWidth,
        "height": window.innerHeight || document.documentElement.clientHeight,
    }
}
/*元素居中*/
function center(_element){
    _element.style.left=((getWindowSize().width-_element.clientWidth)/2+getScrollSize().left)+"px";
    _element.style.top=((getWindowSize().height-_element.clientHeight)/2+getScrollSize().top)+"px";
}
/*页面加载*/
function addLoadEvent(func){
    var oldonload=window.onload;
    if(typeof window.onload != 'function'){
        window.onload=func;
    }else{
        window.onload=function(){
            oldonload();
            func();
        }
    }
}
/*
* 跨浏览器的事件绑定
* */
function addEvent(_element,_type,_fn){
    //判断是否为IE
    if(typeof _element.addEventListener=='undefined'){
        _element.attachEvent("on"+_type,_fn);
    }else{
        _element.addEventListener(_type,_fn);
    }
}
/*
 * 跨浏览器的事件绑定
 * */
/*function addEvent2(_element,_type,_fn,_evt){
    //判断是否为IE
    if(typeof _element.addEventListener=='undefined'){
        _element.attachEvent("on"+_type,_fn);
        _evt=window.event;
        _evt.cancelBubble=true;
    }else{
        _element.addEventListener(_type,_fn);
        _evt.stopPropagation();
    }
}*/
/*
 * 跨浏览器的解除事件绑定
 * */
function removeEvent(_element,_type,_fn){
    //判断是否为IE
    if(typeof _element.addEventListener=='undefined'){
        _element.detachEvent("on"+_type,_fn);
    }else{
        _element.removeEventListener(_type,_fn);
    }
}
/*
* 跨浏览器的获取事件对象
* */
function handleEvent(_evt){
    var e=_evt||window.event;
    return e;
}
/*
* 跨浏览器的阻止事件冒泡
* */
function stopPropagation(_evt){
    if(window.event){
        _evt=window.event;
        _evt.cancelBubble=true;
    }else{
        _evt.stopPropagation();
    }
}
//判断不同的浏览器，把选择的文本结果保存到txt中
function getSelectionText(){
    var txt=null;
    //ff.chrome
    if(window.getSelection){
        //getSelection():获取鼠标选择的文本
        txt=window.getSelection();
        //ie
    }else if(document.selection){
        txt=document.selection.createRange().text;
        //else
    }else if(document.getSelection){
        txt=document.getSelection();
    }
    return txt;
}
//跨浏览器的实例化ajax对象
function createXMLHttpRequest(){
    var xmlHttp;
    //ie
    if(window.ActiveXObject){
        xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
    }else if(window.XMLHttpRequest){
        xmlHttp=new XMLHttpRequest();
    }
    return xmlHttp;
}
/*长度超过_length就修剪，并出现省略号*/
function truncate(_content,_length){
    if(_content.length>_length){
        _content=_content.substr(0,_length)+"...";
    }
    return _content;
}
/*
 * 修剪字符串前后的空格
 * */
function trim(_content){
    var pattern=/^\s*(.+?)\s*$/g;
    _content=_content.replace(pattern,"$1");
    return _content;
}