/**
 * Created by Administrator on 16-6-19.
 */
var mysql=require("mysql");
var connection=mysql.createConnection({
    'host':"localhost",
    "user":"root",
    "password":"",
    "database":"kong"
});
connection.connect();
var queryString="select * from user";
connection.query(queryString,function(err,rows,fields){
    for(var i in rows){
        console.log(rows[i].username);
    }
});
connection.end();
