var fs=require('fs');
fs.readFile("tips.txt","utf8",function(error,data){
    if(error){
        console.log("��ȡ�ⲿ���ݳ���".error);
    }else{
        console.log(data);
    }
});
