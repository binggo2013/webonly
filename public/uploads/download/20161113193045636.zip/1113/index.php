<?php
/**
 * 单入口
 * http://www.demo.com/index.php?a=控制器名&m=控制器的方法；
 * index->Smarty.init.php->Factory::setAction()->Action->run();
 *   
 **/
include 'application/configs/Smarty.init.php';
?>
