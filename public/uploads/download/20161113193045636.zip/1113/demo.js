alert("external js file");
