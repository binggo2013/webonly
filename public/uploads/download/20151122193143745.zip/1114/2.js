/**
 * Created by Administrator on 15-11-15.
 */
addLoadEvent(function(){
    ////////////////////////////
    var ad=document.getElementById("ad");
    console.log(ad);
    /////////////////////
});
