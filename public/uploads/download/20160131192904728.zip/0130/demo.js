/**
 * Created by Administrator on 16-1-30.
 */
var username="tom";