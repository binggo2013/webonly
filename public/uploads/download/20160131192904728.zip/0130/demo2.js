/**
 * Created by Administrator on 16-1-30.
 */
console.log(username);
