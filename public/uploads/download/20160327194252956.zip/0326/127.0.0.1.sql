-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- 主机: 127.0.0.1
-- 生成日期: 2016 年 03 月 27 日 11:29
-- 服务器版本: 5.5.27
-- PHP 版本: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `only2`
--
CREATE DATABASE `only2` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `only2`;

-- --------------------------------------------------------

--
-- 表的结构 `ent`
--

CREATE TABLE IF NOT EXISTS `ent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `ent`
--

INSERT INTO `ent` (`id`, `content`) VALUES
(1, '腾讯体育3月13日讯 中超第2轮比赛，参加亚冠的4支球队取得了3胜1平的不败战绩，鲁能和恒大都及时用一场胜利走出首轮落败的窘境。苏宁则是小胜升班马延边，双线作战豪取3连胜，上港在上海德比中与申花1-1战平。'),
(2, '腾讯体育3月13日讯 中超第2轮比赛，参加亚冠的4支球队取得了3胜1平的不败战绩，鲁能和恒大都及时用一场胜利走出首轮落败的窘境。苏宁则是小胜升班马延边，双线作战豪取3连胜，上港在上海德比中与申花1-1战平。');

-- --------------------------------------------------------

--
-- 表的结构 `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `news`
--

INSERT INTO `news` (`id`, `content`) VALUES
(1, '今天7时50分，在狱中服刑半年、长发剪成短发的李征琴从监狱大门左侧的小门走出。她刚出监狱，孩子的生母便跪倒在李征琴面前痛哭，并大喊，“表姐，我对不起你！”随后，等候在一旁的宝宝迅速扑过去抱住妈妈，李征琴哭着说，“宝宝，妈妈回来了。”3人在监狱大门口哭成一团。'),
(2, '吴双战，武警部队原司令员（上将警衔），2009年退役。在接受新京报记者专访时，吴双战回忆，在腾格里调研过程中，为了确保了解到真实情况，他们不仅听地方上的汇报，还派工作人员到村里暗访。他建议，对重大污染事件，应建立巡视制度来加大监督，用像反腐一样的力度来保护环境。');

-- --------------------------------------------------------

--
-- 表的结构 `search`
--

CREATE TABLE IF NOT EXISTS `search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `searchName` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `search`
--

INSERT INTO `search` (`id`, `searchName`) VALUES
(1, '上'),
(2, '上海'),
(3, '上海市'),
(4, '上海市人'),
(5, '上海市人民'),
(6, '上海市人民政'),
(7, '上海市人民政府');

-- --------------------------------------------------------

--
-- 表的结构 `sports`
--

CREATE TABLE IF NOT EXISTS `sports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `sports`
--

INSERT INTO `sports` (`id`, `content`) VALUES
(1, '新华社长春3月13日体育专电（记者姚友明王昊飞）13日记者从长春大众卓越女足俱乐部获悉，为表彰3名在奥运会亚洲区预选赛中表现出色的队内国脚，俱乐部将向其赠送“里约奥运出线纪念”纯金奖牌'),
(2, '腾讯体育3月13日讯 中超第2轮比赛，参加亚冠的4支球队取得了3胜1平的不败战绩，鲁能和恒大都及时用一场胜利走出首轮落败的窘境。苏宁则是小胜升班马延边，双线作战豪取3连胜，上港在上海德比中与申花1-1战平。');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `pwd` varchar(32) NOT NULL,
  `email` varchar(30) NOT NULL,
  `regTime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `username`, `pwd`, `email`, `regTime`) VALUES
(1, 'tom', '123456', 'tom@tom.com', '2016-03-12 01:11:16'),
(2, 'peter', '123456', 'peter@pter.com', '2016-03-12 00:09:15'),
(3, 'mike', '654321', 'mary@mary.com', '2016-03-12 11:38:44'),
(5, 'mary', '654321', 'mary@mary.com', '2016-03-12 11:57:04'),
(6, 'zhang san', '123456', '', '0000-00-00 00:00:00'),
(7, 'wang wu', '123456', '', '0000-00-00 00:00:00'),
(8, 'libai', '123456', '', '0000-00-00 00:00:00'),
(9, 'libai', '123456', '', '0000-00-00 00:00:00'),
(10, 'libai', '123456', '', '0000-00-00 00:00:00'),
(11, 'libai77', '123456', '', '0000-00-00 00:00:00'),
(12, 'zhaoliu', '123456', '', '0000-00-00 00:00:00'),
(13, 'kong', '123456', '', '0000-00-00 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
