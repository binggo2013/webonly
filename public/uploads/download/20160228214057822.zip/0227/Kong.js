/*小于10的数字加0*/
function addZero(_number){
    if(_number<10){
        _number="0"+_number;
    }else{
        _number=""+_number;
    }
    return _number;
}
/*获取滚动条的尺寸*/
function getScrollSize(){
    return {
        "left":document.documentElement.scrollLeft||document.body.scrollLeft,
        "top":document.documentElement.scrollTop|document.body.scrollTop
    }
}
/*或窗口的尺寸*/
function getWindowSize() {
    return {
        "width": window.innerWidth || document.documentElement.clientWidth,
        "height": window.innerHeight || document.documentElement.clientHeight,
    }
}
/*元素居中*/
function center(_element){
    _element.style.left=((getWindowSize().width-_element.clientWidth)/2+getScrollSize().left)+"px";
    _element.style.top=((getWindowSize().height-_element.clientHeight)/2+getScrollSize().top)+"px";
}
/*页面加载*/
function addLoadEvent(func){
    var oldonload=window.onload;
    if(typeof window.onload != 'function'){
        window.onload=func;
    }else{
        window.onload=function(){
            oldonload();
            func();
        }
    }
}