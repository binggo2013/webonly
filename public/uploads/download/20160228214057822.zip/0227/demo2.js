/**
 * Created by Administrator on 16-2-28.
 */
addLoadEvent(function(){
    console.log(document.body+"2");
});