<?php
$arr=array("isRandom"=>true,"maxSize"=>"23333");
echo array_key_exists("isRandom", $arr);
/* array(11) {
  ["errorMsg"]=>
  NULL
  ["isRandom"]=>
  NULL
  ["originalName"]=>
  NULL
  ["tmpName"]=>
  NULL
  ["newName"]=>
  NULL
  ["size"]=>
  NULL
  ["type"]=>
  NULL
  ["maxSize"]=>
  NULL
  ["allowType"]=>
  NULL
  ["path"]=>
  NULL
  ["errorNum"]=>
  NULL */

?>