<?php
include 'Transfer.class.php';
echo "<pre>";
//var_dump($_FILES);
echo "</pre>";
$transfer=new Transfer(array("fieldName"=>"bbb","maxSize"=>5000000));
if($_POST['send']){
    if($transfer->upload("bbb")){
        echo "上传成功";
    }else{
        echo $transfer->getError();
    }
}
?>