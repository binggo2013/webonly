<?php
//var_dump($_POST);
echo "<pre>";
var_dump($_FILES);
echo "</pre>";
if($_POST['send']){
    for($i=0;$i<count($_FILES['icon']['name']);$i++){
        //echo $i."<br>";
        move_uploaded_file($_FILES['icon']['tmp_name'][$i], $_FILES['icon']['name'][$i]);
    }
    //move_uploaded_file($_FILES['icon']['tmp_name'], $_FILES['icon']['name']);
}
?>