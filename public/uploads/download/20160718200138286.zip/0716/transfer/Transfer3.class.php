<?php
/**
 * 上传第二版
 * 1.统一的错误处理
 * 2.自定义input的name值;
 * 3.setNewName()新文件名;
 * 4.iconv():处理中文，把utf8字符集转换成gb2312字符集
 * @author Administrator
 *  */
class Transfer{
    private $errorMsg;
    private $isRandom;
    //上传文件的原来名称
    private $originalName;
    //上传文件的临时文件名
    private $tmpName;
    //上传文件的新文件名
    private $newName;
    //上传文件的大小
    private $size;
    //上传文件的类型
    private $type;
    public function __construct($_fieldName,$_isRandom=true){
        $this->isRandom=$_isRandom;
        $this->uploadedFileInfo($_fieldName);
        $this->setNewName();
    }
    /**
     * 设置上传文件的新名称
     *   */
    private function setNewName(){
        if($this->isRandom){
            $this->newName=date("YmdHis").rand(100,999).".".$this->type;
        }else{
            $this->newName=$this->originalName;
        }
        //echo $this->newName;
    }
    private function uploadedFileInfo($_fieldName){
        //iconv：处理中文文件名;
        $this->originalName=iconv("utf-8","gb2312", $_FILES[$_fieldName]['name']);
        $arr=explode(".",$this->originalName);
        /* echo "<pre>";
        var_dump($arr);
        echo "</pre>"; */
        $this->type=$arr[count($arr)-1];
        $this->tmpName=$_FILES[$_fieldName]['tmp_name'];
        $this->size=$_FILES[$_fieldName]['size'];
        echo $this->size."<br>";
    }
    public function getError(){
        return $this->errorMsg;
    }
    public function upload($_fieldName){
        //判断临时文件是否生成
        if(is_uploaded_file($_FILES[$_fieldName]['tmp_name'])){
            //判断是否移动成功
            if(move_uploaded_file($_FILES[$_fieldName]['tmp_name'], $this->newName)){
                //$this->errorMsg="上传成功!";
                //echo iconv("gb2312","utf-8",$this->originalName);
                return true;
            }else{
                $this->errorMsg="临时文件移动失败";
            }
        }else{
            $this->errorMsg="没有文件上传";
        }
    }
}
?>