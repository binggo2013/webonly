<?php
/**
 * 上传第一版
 * 1.统一的错误处理
 * 2.自定义input的name值;
 * @author Administrator
 *  */
class Transfer{
    private $errorMsg;
    public function getError(){
        return $this->errorMsg;
    }
    public function upload($_fieldName){
        //判断临时文件是否生成
        if(is_uploaded_file($_FILES[$_fieldName]['tmp_name'])){
            //判断是否移动成功
            if(move_uploaded_file($_FILES[$_fieldName]['tmp_name'], $_FILES[$_fieldName]['name'])){
                //$this->errorMsg="上传成功!";
                return true;
            }else{
                $this->errorMsg="临时文件移动失败";
            }
        }else{
            $this->errorMsg="没有文件上传";
        }
    }
}
?>