<?php
/**
 * page第一版
 * 1.传每页显示的数据条数
 * 2.通过地址栏传值
 * @author Administrator
 *  */
class Page{
    public $limit;
    //每页数据条数
    public $listRows;
    public $page;
    public function __construct($_listRows=5){
        $this->listRows=$_listRows;
        //如果地址栏传了page就等于这个值，每页传就等于1;
        $this->page=!empty($_GET['page'])?$_GET['page']:1;
        //$sql="select * from user limit ($page-1)*$listRows,$listRows";
        $this->limit=" limit ".($this->page-1)*$this->listRows.",".$this->listRows;
    }
}
?>