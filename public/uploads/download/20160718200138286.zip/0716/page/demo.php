<?php
echo "<pre>";
$member=array("username"=>"tom","level"=>"VIP");
var_dump($member);
function assign($_arr,$_username,$_v){
    foreach ($_arr as $key=>$value){
        //array_key_exists:判断key是否是数组的下标
        if(array_key_exists($_username, $_arr)){
            $_arr[$_username]=$_v;
        }
    }
    //var_dump($_arr);
    return $_arr;
}
var_dump(assign($member,"level","VIP234234"));
echo "<pre>";
?>