<?php
/**
 * page第一版
 * 1.传每页显示的数据条数
 * 2.通过地址栏传值
 * 3.添加display方法，可以显示：首页，末页，上一页，下一页,当前页/总页数
 * @author Administrator
 *  */
class Page{
    public $limit;
    //每页数据条数
    public $listRows;
    public $page;
    //总记录数
    public $total;
    //总页数
    public $pageNum;
    public function __construct($_total,$_listRows=5){
        $this->total=$_total;
        $this->listRows=$_listRows;
        //如果地址栏传了page就等于这个值，每页传就等于1;
        $this->page=!empty($_GET['page'])?$_GET['page']:1;
        //获取总页数
        $this->pageNum=ceil($this->total/$this->listRows);
        //$sql="select * from user limit ($page-1)*$listRows,$listRows";
        $this->limit=" limit ".($this->page-1)*$this->listRows.",".$this->listRows;
    }
    /**
     * 显示首页，如果当前页是1的话，每页链接，其它有链接
     * @return string $str;
     *   */
    private function first(){
        $str=null;
        if($this->page==1){
            $str="<li>首页</li>";
        }else{
            $str="<li><a href='?page=1'>首页</a></li>";
        }
        return $str;
    }
    /**
     * 显示末页，如果当前页是种页数的话，没链接，其它有链接
     * @return string $str;
     *   */
    private function end(){
        $str=null;
        if($this->page==$this->pageNum){
            $str="<li>末页</li>";
        }else{
            $str="<li><a href='?page=".$this->pageNum."'>末页</a></li>";
        }
        return $str;
    }
    private function present(){
        return "<li>".$this->page."/".$this->pageNum."</li>";
    }
    private function prev(){
        $str=null;
        if($this->page==1){
            $str="<li>上一页</li>";
        }else{
            $str="<li><a href='?page=".($this->page-1)."'>上一页</a></li>";
        }
        return $str;
    }
    private function next(){
        $str=null;
        if($this->page==$this->pageNum){
            $str="<li>下一页</li>";
        }else{
            $str="<li><a href='?page=".($this->page+1)."'>下一页</a></li>";
        }
        return $str;
    }
    public function display(){
        $str=null;
        $str="<ul>";
        $str.=$this->first();
        $str.=$this->prev();
        $str.=$this->present();
        $str.=$this->next();
        $str.=$this->end();
        $str.="</ul>";
        return $str;
    }
}
?>