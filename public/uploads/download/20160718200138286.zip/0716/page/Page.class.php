<?php
/**
 * page第七版
 * 1.传每页显示的数据条数
 * 2.通过地址栏传值
 * 3.添加display()方法，可以显示：首页，末页，上一页，下一页,当前页/总页数
 * 4.handlePage():处理页面范围
 * 5.__set(),__get():类的私有属性的重载;
 * 6.pageList()：循环出当前页的前面3页，后面3页
 * 7.first()和end()显示省略号
 * 8.reWrite()重写url,针对有查询字符串和没有查询字符串的情况;
 * 9.setConfig()可以在外部重写分页的单位
 * 10.getError()统一的错误信息;
 * @todo end()省略号
 * @author Administrator
 *  */
class Page{
    private $limit;
    //每页数据条数
    private $listRows;
    private $page;
    //总记录数
    private $total;
    //总页数
    private $pageNum;
    private $num;
    private $url;
    private $config=array("next"=>"下一页","prev"=>"前一页");
    private $erroMsg;
    public function __construct($_total,$_listRows=5,$_num=3){
        $this->num=$_num;
        $this->total=$_total;
        $this->listRows=$_listRows;
        //如果地址栏传了page就等于这个值，每页传就等于1;
        //$this->page=!empty($_GET['page'])?$_GET['page']:1;
        //获取总页数
        $this->pageNum=ceil($this->total/$this->listRows);
        $this->handlePage();
        //$sql="select * from user limit ($page-1)*$listRows,$listRows";
        $this->limit=" limit ".($this->page-1)*$this->listRows.",".$this->listRows;
        $this->url=$this->reWrite();
    }
    public function getError(){
        return $this->erroMsg;
    }
    public function setConfig($_config){
        if($_config){
            if(is_array($_config)){
                foreach ($_config as $_key=>$_value){
                    if(array_key_exists($_key, $this->config)){
                        $this->config[$_key]=$_value;
                    }else{
                        $this->erroMsg="数组的下标错误";
                    }
                }
            }else{
                $this->erroMsg="setConfig必须是数组";
            }
        }else{
            $this->erroMsg="setConfig参数不得为空";
        }
    }
    public function __set($_key,$_value){
        $this->$_key=$_value;
    }
    public function __get($_key){
        return $this->$_key;
    }
    private function reWrite(){
        $newURL=null;
        ///echo "<pre>";
        //var_dump($_SERVER["REQUEST_URI"]);
        $url=$_SERVER["REQUEST_URI"];
        //parse_url：把URL解析为数组，数组元素为url的组件
        //query就是查询字符串;
        $parseURL=parse_url($url);
        //var_dump(parse_url($url));
        //echo "</pre>";
        //如果查询字符串有值
        if(isset($parseURL['query'])){
            //echo "yes";
            //把字符串解析为数组
            parse_str($parseURL['query'],$arr);
            //var_dump($arr);
            unset($arr['page']);
            //var_dump($arr);
            //http_build_query:把数组元素重新生成查询字符串
            $newURL=$parseURL['path']."?".http_build_query($arr);
        }else{
            $newURL=$parseURL['path']."?";
        }
        return $newURL;
    }
    /**
     * 处理当前页的范围
     *   $str=null;
        $num=100;
        for($i=1;$i<=5;$i++){
            echo ($num-$i)."<br>";
        }
     *   */
    private function handlePage(){
        $this->page=!empty($_GET['page'])?$_GET['page']:1;
        if($this->page>$this->pageNum){
            $this->page=$this->pageNum;
        }
        if($this->page<1){
            $this->page=1;
        }
        
    }
    /**
     * 循环出当前页，当前页之前和之后的页数,
     * 不符合逻辑的话，显示省略号
     * @return string  */
    private function pageList(){
        $prev=null;
        $next=null;
        //当前页之前的页面
        for($i=$this->num;$i>=1;$i--){
            if($this->page-$i<1){
                continue;
            }else{
                //$prev.="<li><a href='?page=".($this->page-$i)."'>".($this->page-$i)."</a></li>";
                $prev.="<li><a href='".$this->url."&page=".($this->page-$i)."'>".($this->page-$i)."</a></li>";
            }
        }
        //当前页
        $present="<li class='present'>".$this->page."</li>";
        //当前页之后的页面
        for($j=1;$j<=$this->num;$j++){
            if($this->page+$j<=$this->pageNum){
                $next.="<li><a href='".$this->url."&page=".($this->page+$j)."'>".($this->page+$j)."</a></li>";
            }else{
                break;
            }
        }
        return $prev.$present.$next;
    }
    /**
     * 显示首页，如果当前页是1的话，每页链接，其它有链接
     * @return string $str;
     *   */
    private function first(){
        $str=null;
        if($this->page==1){
            //$str="<li>首页</li>";
            $str=null;
        }else if($this->page>$this->num+2){
            $str="<li><a href='".$this->url."&page=1'>1</a></li><li>...</li>";
            //$str="<li><a href='?page=1'>首页</a></li>";
        }else if($this->page>$this->num+1){
            $str="<li><a href='".$this->url."&page=1'>1</a></li>>";
        }
        return $str;
    }
    /**
     * 显示末页，如果当前页是种页数的话，没链接，其它有链接
     * @return string $str;
     *   */
    private function end(){
        $str=null;
        if($this->page==$this->pageNum){
            //$str="<li>末页</li>";
            echo "end";
            $str=null;
        }elseif($this->num-$this->page<$this->num+1){
            $str="<li>...</li><li><a href='".$this->url."&page=".($this->pageNum)."'>".($this->pageNum)."</a></li>";
        }else if($this->num-$this->page<$this->num){
            $str="<li><a href='".$this->url."&page=".($this->pageNum)."'>".($this->pageNum)."</a></li>";
        }
        return $str;
    }
    private function present(){
        return "<li>".$this->page."/".$this->pageNum."</li>";
    }
    private function prev(){
        $str=null;
        if($this->page==1){
            $str="<li>上一页</li>";
        }else{
            $str="<li><a href='".$this->url."&page=".($this->page-1)."'>".$this->config['prev']."</a></li>";
        }
        return $str;
    }
    private function next(){
        $str=null;
        if($this->page==$this->pageNum){
            $str="<li>下一页</li>";
        }else{
            $str="<li><a href='".$this->url."&page=".($this->page+1)."'>".$this->config['next']."</a></li>";
        }
        return $str;
    }
    //输入或者调整范围跳转页面;
    private function jump(){
        $str=null;
        $str="<li><input type='number' min=1 max=".($this->pageNum)." id='pageValue' value='".($this->page)."' style='width:100%;border:0;text-align:center'></li>";
        return $str;
    }
    public function display($_data=array(0,1,2,3,4,5)){
        $str=null;
        $str="<ul>";        
        if(is_array($_data)){
            $ui[0]=$this->prev();
            $ui[1]=$this->first();
            //$str.=$this->present();
            $ui[2]=$this->pageList();
            $ui[3]=$this->end();
            $ui[4]=$this->next();
            $ui[5]=$this->jump();
            //var_dump($ui);
            //var_dump($_data);
            //$data=array(0,1,2,3,4,5);
            foreach ($_data as $key=>$value){
                //in_array:检查value是否在数组中
                if(in_array($value,$_data)){
                    $str.=$ui[$value];
                }else{
                    
                }
            }
        }else{
            $this->erroMsg="display参数必须是数组";
        }
        $str.="</ul>";
        return $str;
    }
}
?>

