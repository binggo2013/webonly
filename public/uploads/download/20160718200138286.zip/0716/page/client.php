<?php
include 'Ajax_Page.class.php';
/* if($_GET['action']=="show"){
    echo "<img src='1.jpg'><br>";
} */
//include 'Tools.class.php';
$pdo=new PDO("mysql:host=localhost;dbname=kong","root","");
//var_dump($pdo);
$pdo->query("set names utf8");
$total=$pdo->query("select * from user")->rowCount();
//echo $total;
$page=new Ajax_Page($total,3);
//$page->setConfig(array("next"=>"next page",'prev'=>"prev page"));

//echo $page->limit."<br>";
//通过在地址栏传page进行分页;
$sql="select * from user ".$page->limit;
//echo $sql;
$result=$pdo->query($sql);
$data=$result->fetchAll(PDO::FETCH_OBJ);
//Tools::dump($data);
foreach ($data as $key=>$value){
    echo $value->username."<br>";
}
echo "<hr>";
echo $page->display();
echo $page->getError()."<br>";
?>
<style>
ul{
	list-style:none;
}
ul li{
	float:left;
	width:55px;
	height:55px;
	line-height:55px;
	text-align:center;
	border:1px solid green;
	margin-left:15px;	
}
.present{
	background:orange;
	color:white;
}
</style>
<script>
	console.log(new Date());
	var xhr=new XMLHttpRequest();
	//console.log(xhr);
	setPage("client.php?page=1");
	//根据不同的url执行ajax
	function setPage(_url){
		xhr.open("get",_url);
		xhr.send(null);
		xhr.addEventListener("readystatechange",function(){
			if(xhr.readyState==4){
				if(xhr.status==200){
					console.log(xhr.responseText);
				}
			}
		});
	}
	var pageValue=document.getElementById("pageValue");
	var pageSelect=document.getElementById("pageSelect");
	/* pageSelect.addEventListener("change",function(){
		location.href="?page="+this.value;
	}); */
	//console.log(pageValue);
	//范围
	pageValue.addEventListener("click",function(){
		location.href="?page="+this.value;
	});
	pageValue.addEventListener("keyup",function(){
		//console.log(this.value);
		location.href="?page="+this.value;
	});
</script>