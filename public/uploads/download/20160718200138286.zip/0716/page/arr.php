<?php
$demo=array(5);
var_dump($demo);
?>