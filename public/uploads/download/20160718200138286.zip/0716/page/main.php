<?php
include "Ajax_Page.class.php";
$pdo=new PDO("mysql:host=localhost;dbname=kong","root","");
//var_dump($pdo);
$pdo->query("set names utf8");
$q=$pdo->query("select * from user");
$total=$q->rowCount();
//echo $total;
$page=new Ajax_Page($total, 3);
//var_dump($page);
$sql="select * from user order by id desc ".$page->limit;
$query=$pdo->query($sql);
//echo "<pre>";
//var_dump($query->fetchAll(PDO::FETCH_OBJ));
//把数据和分页分别放在数组中,再把数组json化.
$temp=null;
//数据
$temp[0]=$query->fetchAll(PDO::FETCH_OBJ);
//分页
$temp[1]=$page->display();
echo json_encode($temp);

//echo "</pre>";
?>