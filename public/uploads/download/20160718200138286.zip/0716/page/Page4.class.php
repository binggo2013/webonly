<?php
/**
 * page第四版
 * 1.传每页显示的数据条数
 * 2.通过地址栏传值
 * 3.添加display()方法，可以显示：首页，末页，上一页，下一页,当前页/总页数
 * 4.handlePage():处理页面范围
 * 5.__set(),__get():类的私有属性的重载;
 * 6.pageList()：循环出当前页的前面3页，后面3页。
 * @author Administrator
 *  */
class Page{
    private $limit;
    //每页数据条数
    private $listRows;
    private $page;
    //总记录数
    private $total;
    //总页数
    private $pageNum;
    private $num;
    public function __construct($_total,$_listRows=5,$_num=3){
        $this->num=$_num;
        $this->total=$_total;
        $this->listRows=$_listRows;
        //如果地址栏传了page就等于这个值，每页传就等于1;
        //$this->page=!empty($_GET['page'])?$_GET['page']:1;
        //获取总页数
        $this->pageNum=ceil($this->total/$this->listRows);
        $this->handlePage();
        //$sql="select * from user limit ($page-1)*$listRows,$listRows";
        $this->limit=" limit ".($this->page-1)*$this->listRows.",".$this->listRows;
    }
    public function __set($_key,$_value){
        $this->$_key=$_value;
    }
    public function __get($_key){
        return $this->$_key;
    }
    /**
     * 处理当前页的范围
     *   $str=null;
        $num=100;
        for($i=1;$i<=5;$i++){
            echo ($num-$i)."<br>";
        }
     *   */
    private function handlePage(){
        $this->page=!empty($_GET['page'])?$_GET['page']:1;
        if($this->page>$this->pageNum){
            $this->page=$this->pageNum;
        }
        if($this->page<1){
            $this->page=1;
        }
        
    }
    private function pageList(){
        $prev=null;
        $next=null;
        //当前页之前的页面
        for($i=$this->num;$i>=1;$i--){
            if($this->page-$i<1){
                continue;
            }else{
                $prev.="<li><a href='?page=".($this->page-$i)."'>".($this->page-$i)."</a></li>";
            }
        }
        //当前页
        $present="<li class='present'>".$this->page."</li>";
        //当前页之后的页面
        for($j=1;$j<=$this->num;$j++){
            if($this->page+$j<=$this->pageNum){
                $next.="<li><a href='?page=".($this->page+$j)."'>".($this->page+$j)."</a></li>";
            }else{
                break;
            }
        }
        return $prev.$present.$next;
    }
    /**
     * 显示首页，如果当前页是1的话，每页链接，其它有链接
     * @return string $str;
     *   */
    private function first(){
        $str=null;
        if($this->page==1){
            $str="<li>首页</li>";
        }else{
            $str="<li><a href='?page=1'>首页</a></li>";
        }
        return $str;
    }
    /**
     * 显示末页，如果当前页是种页数的话，没链接，其它有链接
     * @return string $str;
     *   */
    private function end(){
        $str=null;
        if($this->page==$this->pageNum){
            $str="<li>末页</li>";
        }else{
            $str="<li><a href='?page=".$this->pageNum."'>末页</a></li>";
        }
        return $str;
    }
    private function present(){
        return "<li>".$this->page."/".$this->pageNum."</li>";
    }
    private function prev(){
        $str=null;
        if($this->page==1){
            $str="<li>上一页</li>";
        }else{
            $str="<li><a href='?page=".($this->page-1)."'>上一页</a></li>";
        }
        return $str;
    }
    private function next(){
        $str=null;
        if($this->page==$this->pageNum){
            $str="<li>下一页</li>";
        }else{
            $str="<li><a href='?page=".($this->page+1)."'>下一页</a></li>";
        }
        return $str;
    }
    public function display(){
        $str=null;
        $str="<ul>";
        $str.=$this->first();
        $str.=$this->prev();
        //$str.=$this->present();
        $str.=$this->pageList();
        $str.=$this->next();
        $str.=$this->end();
        $str.="</ul>";
        return $str;
    }
}
?>

