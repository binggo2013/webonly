<?php
    if($_POST['username']=="tom"){
        echo "ok";
    }else{
        echo "failed";
    }
?>