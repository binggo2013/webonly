<?php /* Smarty version 3.1.29, created on 2016-07-09 09:30:33
         compiled from "C:\xampp\htdocs\php2\0709\configs\a.b" */ ?>
<?php
/* Smarty version 3.1.29, created on 2016-07-09 09:30:33
  from "C:\xampp\htdocs\php2\0709\configs\a.b" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5780a819eb1ff6_84294648',
  'file_dependency' => 
  array (
    '3e602790e661f4204558864f02a92c4e2967df39' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php2\\0709\\configs\\a.b',
      1 => 1468049128,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5780a819eb1ff6_84294648 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'website' => 
    array (
      'vars' => 
      array (
        'host' => 'www.webonly.org',
        'user' => 'root',
        'pwd' => 'root',
      ),
    ),
    'register' => 
    array (
      'vars' => 
      array (
        'rid' => '��234345234',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
