<?php
/* Smarty version 3.1.29, created on 2016-07-09 11:09:10
  from "C:\xampp\htdocs\php2\0709\templates\demo1.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5780bf361037f0_06777153',
  'file_dependency' => 
  array (
    'bd6c85a856bcd6b20fc028496f15b677c58cd912' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php2\\0709\\templates\\demo1.html',
      1 => 1468055335,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5780bf361037f0_06777153 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<?php
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, 'config.conf', 'website', 0);
?>

<title><?php echo $_smarty_tpl->smarty->ext->configload->_getConfigVariable($_smarty_tpl, 'host');?>
</title>
</head>
<body>
<img src="logo_left.png">
<h1>hello</h1>
<h2><?php echo $_smarty_tpl->tpl_vars['username']->value;?>
</h2>
<h3><?php echo $_smarty_tpl->tpl_vars['member']->value['username'];?>
</h3>
<h4><?php echo $_smarty_tpl->tpl_vars['car']->value->color;?>
</h4>
<h5><?php echo $_smarty_tpl->tpl_vars['num1']->value+$_smarty_tpl->tpl_vars['num2']->value;?>
</h5>
<?php
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, 'config.conf', 'website', 0);
?>

<?php
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, 'config.conf', 'register', 0);
?>

<?php echo $_smarty_tpl->smarty->ext->configload->_getConfigVariable($_smarty_tpl, 'host');?>
||<?php echo $_smarty_tpl->smarty->ext->configload->_getConfigVariable($_smarty_tpl, 'pwd');?>
||<?php echo $_smarty_tpl->smarty->ext->configload->_getConfigVariable($_smarty_tpl, 'rid');?>

</body>
</html><?php }
}
