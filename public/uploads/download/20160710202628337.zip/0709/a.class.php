<?php
class a{
    public $username="stan Lee";
}
?>