<?php
//include 'a.class.php';
//include 'b.class.php';
//include 'libs/Smarty.class.php';
//$smarty=new Smarty();
//spl:second programme load 
spl_autoload_register("MyLoad");
function MyLoad($_className){
    include $_className.'.class.php';
}
$A=new a();
echo $A->username;
$B=new b();
echo $B->num;
$C=new c();
echo $C->add;
?>