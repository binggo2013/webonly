<?php
include 'Tools.php';
try{
    //尝试执行的代码
    $pdo=new PDO("mysql:host=localhost;dbname=kong","root","");
}catch (PDOException $e){
    //捕获异常
    echo $e->getMessage();
}finally {
    //始终执行;
    echo "hello<br>";
}
$pdo->query("set names utf8");
$result=$pdo->query("select * from user");
//dump($result);
//dump($result->fetch(PDO::FETCH_OBJ));
//dump(json_encode($result->fetch(PDO::FETCH_OBJ)));
//dump($result->fetchAll(PDO::FETCH_OBJ));
echo $result->rowCount();
dump($result->fetchObject());
?>