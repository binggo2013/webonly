<?php
class gif extends Image{
    
}
?>