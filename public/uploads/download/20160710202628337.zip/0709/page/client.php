<?php
include 'Page.class.php';
include '../includes/Tools.class.php';
$pdo=new PDO("mysql:host=localhost;dbname=kong","root","");
//var_dump($pdo);
$pdo->query("set names utf8");
$total=$pdo->query("select * from user")->rowCount();
//echo $total;
$page=new Page($total,3);
echo $page->limit."<br>";
//通过在地址栏传page进行分页;
$sql="select * from user ".$page->limit;
$result=$pdo->query($sql);
$data=$result->fetchAll(PDO::FETCH_OBJ);
//Tools::dump($data);
foreach ($data as $key=>$value){
    echo $value->username."<br>";
}
echo "<hr>";
echo $page->display();
?>