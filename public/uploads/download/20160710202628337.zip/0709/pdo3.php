<?php
include 'Tools.php';
try{
    //尝试执行的代码
    $pdo=new PDO("mysql:host=localhost;dbname=kong","root","");
}catch (PDOException $e){
    //捕获异常
    echo $e->getMessage();
}finally {
    //始终执行;
    echo "hello<br>";
}
$pdo->query("set names utf8");
//关闭自动提交
$pdo->setAttribute(PDO::ATTR_AUTOCOMMIT, 0);
//初始化交易
$pdo->beginTransaction();
$sql="update zhang set money=money-500 where id=1";
$num_rows=$pdo->exec($sql);
if(!$num_rows){
    echo "付款失败";
}
$sql2="update wang set money=money+500 where id=1;";
$num_rows2=$pdo->exec($sql2);
if(!$num_rows2){
    echo "收款失败";
}
if($num_rows && $num_rows2){
    $pdo->commit();
    echo "交易成功";
}else{
    $pdo->rollBack();
    echo "交易失败";
}
$pdo->setAttribute(PDO::ATTR_AUTOCOMMIT, 1);
?>