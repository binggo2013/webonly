<?php
class b{
    public $num=100;
}
?>