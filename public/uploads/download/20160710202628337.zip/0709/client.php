<?php
error_reporting(E_ALL);
include 'Image.php';
include 'png.php';
include 'gif.php';
$p=new png("300px","300px", "png");
echo $p->getColor();

/* echo $p->getInfo()."<br>";
$g=new gif("1200px","1200px", "gif");
echo $g->getInfo()."<br>";
echo $p->copyright()."<br>";
echo $p->getAuthor()."<br>";
echo $p->author."<br>"; */
/* $i=new Image(44, 444, 444);
var_dump($i); */
?>