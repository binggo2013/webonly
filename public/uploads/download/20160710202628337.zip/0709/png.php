<?php
class png extends Image{
    private $foo="abc";
    public $author='张三';
    public function __construct(){
        return "父类的作者是：".parent::getAuthor();
    }
    public function copyright(){
        return "png";
    }
    public function getColor(){
        return $this->color;
    }
}
?>