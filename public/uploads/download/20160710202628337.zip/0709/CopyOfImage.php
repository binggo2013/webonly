<?php
class Image{
    public $width;
    public $height;
    public $type;
    public $author="tom lee";
    public function __construct($_width,$_height,$_type){
        $this->width=$_width;
        $this->height=$_height;
        $this->type=$_type;
        return $this->author;
    }
    public function getAuthor(){
        return $this->author;
    }
    public function getInfo(){
        return $this->type.$this->width.$this->height;
    }
    public function copyright(){
        return "Image";
    }
}
?>