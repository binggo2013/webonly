<?php
include 'Tools.php';
$name="tom";
//dump(isset($name));
$_SESSION['username']="peter";
dump(isset($_SESSION['username']));
?>