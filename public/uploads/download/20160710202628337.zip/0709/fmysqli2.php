<?php
error_reporting(E_ALL ^ E_WARNING);
include 'Tools.php';
//链接mysql服务器
$mysqli=new mysqli("localhost","root","","kong");
//跑错
if(mysqli_connect_errno()){
    exit("failed");
}
$mysqli->set_charset("utf8");
$sql="update user set username='张张张'where id=35;
      update user set username='网网'where id=31";
$result=$mysqli->multi_query($sql);
dump($result);
?>