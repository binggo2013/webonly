<?php
abstract class demo{
    public abstract function Msg();
}
class a extends demo{
    public function Msg(){
        return "hello";
    }
}
$A=new a();
var_dump($A);
?>