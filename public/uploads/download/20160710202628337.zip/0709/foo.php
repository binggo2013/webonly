<?php
class foo{
    private $color="red";
    private $username="tom";
    public function __set($_key,$_value){
        $this->$_key=$_value;
    }
    public function __get($_key){
        return $this->$_key;
    }
    public static function demo(){
        echo "hello";
    }
    /* //设置颜色
    public function setColor($_color){
        $this->color=$_color;
    }
    public function getColor(){
        return $this->color;
    } */
}
$f=new foo();
$f->color="blue";
echo $f->color;
echo $f->demo();
echo foo::demo();
/* $f->setColor("black");
echo $f->getColor(); */
?>