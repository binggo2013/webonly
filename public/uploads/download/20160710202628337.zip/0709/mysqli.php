<?php
error_reporting(E_ALL ^ E_WARNING);
include 'Tools.php';
//链接mysql服务器
$mysqli=new mysqli("localhost","root","","kong");
//跑错
if(mysqli_connect_errno()){
    exit("failed");
}
//dump($mysqli);
//设置操作数据库的字符集
//mysql_query("set names utf8");
$mysqli->set_charset("utf8");
$sql="select * from user";
$result=$mysqli->query($sql);
//dump($result);
echo $result->num_rows."条数据<br>";
//dump($result->fetch_row());
//dump($result->fetch_array());
//dump($result->fetch_assoc());
//dump($result->fetch_object());
//echo json_encode($result->fetch_assoc());
//echo json_encode($result->fetch_array());
//dump($result->fetch_assoc());
//dump($result->fetch_assoc());
while($data=$result->fetch_assoc()){
    dump($data);
}
?>