<?php
error_reporting(E_ALL);
include "d.php";
include "e.php";
echo kong\username;
echo king\username;
echo kong\demo();
?>