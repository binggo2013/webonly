-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2016-07-10 11:29:48
-- 服务器版本： 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kong`
--

-- --------------------------------------------------------

--
-- 表的结构 `user`
--
-- 创建时间： 2016-07-02 09:22:10
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(22) NOT NULL,
  `regTime` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `regTime`) VALUES
(2, 'tom3', 'tom@tom.com', '2016-07-03 09:25:23'),
(4, 'tom33333', 'tom@tom.com', '2016-07-03 09:45:59'),
(5, '张三', 'zhang@tom.com', '2016-07-03 09:45:59'),
(6, 'tom3', 'tom@tom.com', '2016-07-03 10:38:04'),
(7, 'jenenifer', 'tom@tom.com', '2016-07-03 10:38:18'),
(9, '赵六', 'zhao@tom.com', '2016-07-03 10:43:33'),
(11, 'sarah', 'sarah@tom.com', '2016-07-03 10:46:50'),
(12, 'amanda', 'sarah@tom.com', '2016-07-03 10:51:23'),
(16, 'will Smith', 'will@will.com', '2016-07-03 13:42:00'),
(17, 'Independence Day', 'will@will.com2', '2016-07-03 13:42:26'),
(18, 'zack', 'dadada', '2016-07-03 13:50:21'),
(19, '上海', '123456', '2016-07-03 13:51:17'),
(20, '新数据', '123456', '2016-07-03 17:06:20'),
(21, '新数据222', '123456', '2016-07-03 17:09:07'),
(22, '最后一次尝试', '2131234', '2016-07-03 17:10:07'),
(23, '阿斯顿发斯蒂芬', '234234234', '2016-07-03 17:10:45'),
(24, '444', '34345', '2016-07-03 17:11:00'),
(25, '234234', '234', '2016-07-03 17:12:15'),
(26, 'mary', '32', '2016-07-03 17:13:02'),
(27, '字符串', '234234234', '2016-07-03 17:14:16'),
(31, '网网', '123123', '2016-07-09 09:04:37'),
(35, '张张张', '234', '2016-07-09 09:09:33'),
(36, 'a', 'b', '2016-07-09 13:16:08'),
(37, 'a', 'b', '2016-07-09 13:19:38'),
(38, 'ashley', 'ashley@ashley.com', '2016-07-09 13:29:12'),
(39, 'stanLee', 'stanLee@ashley.com', '2016-07-09 13:35:13'),
(40, 'ttt', 'ttt@ttt.com', '2016-07-09 13:44:37');

-- --------------------------------------------------------

--
-- 表的结构 `wang`
--
-- 创建时间： 2016-07-09 02:40:48
--

CREATE TABLE IF NOT EXISTS `wang` (
  `id` int(11) NOT NULL,
  `money` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `wang`
--

INSERT INTO `wang` (`id`, `money`) VALUES
(1, 3000);

-- --------------------------------------------------------

--
-- 表的结构 `zhang`
--
-- 创建时间： 2016-07-09 02:37:23
--

CREATE TABLE IF NOT EXISTS `zhang` (
  `id` int(11) NOT NULL,
  `money` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `zhang`
--

INSERT INTO `zhang` (`id`, `money`) VALUES
(1, 1000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wang`
--
ALTER TABLE `wang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zhang`
--
ALTER TABLE `zhang`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `wang`
--
ALTER TABLE `wang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `zhang`
--
ALTER TABLE `zhang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
