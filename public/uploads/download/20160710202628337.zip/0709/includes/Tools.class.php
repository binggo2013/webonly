<script src="tools.js"></script>
<script>
	window.addEventListener("load",function(){
		Redirect();
	});
</script>
<link href='tools.css' rel="stylesheet">
<style>
body{
	min-height:600px;
}
</style>
<?php
session_start();
final class Tools{
/**
 * 重定向函数，必须配合Tools.js和Tools.css
 * @param string $_msg:要显示的信息
 * @param string $_url:要跳转的路径
 * @param number $_t:重定向需要的时间，默认是3秒钟;
 * @param number $_flag:1是成功,0是失败
 * 
 *   */
public static function Redirect($_msg,$_url,$_flag=1,$_t=13){
    if($_flag==1){
        $color="green;";
    }else if($_flag==0){
        $color="red;";
    }
    echo "<div id='Redirect' data-countdown=".$_t." data-url=".$_url.">";
    echo "<span style='color:".$color."'>".$_msg."</span>";
    echo "&nbsp;<span id='timer'>".$_t."</span>";
    echo "</div>";
}
/**
 * 判断session是否有值
 * @param string $_data  
 * @return bool:没值为true，有值为false;
 * */
public static  function hasSession($_data){
    if(!isset($_SESSION[$_data])){
        return true;
    }
    return false;
}
/**
 * 判断用户的等级
 * @param string $_data  */
public static function hasPermission($_data){
    if(!strstr($_SESSION['permission'],$_data)){
        return true;
    }
    return false;
}
/**
 * 销毁指定的session值
 * @param string $_data
 * @return boolean  */
public function destroySession($_data){
    unset($_SESSION[$_data]);
    return true;
}
/**
 * 过滤字符串、数组、对象
 * 
 * @param mixed $_content  
 * @return mixed;
 * */
public static function filter($_content){
    if(is_string($_content)){
        $_content=htmlspecialchars($_content);
    }else if(is_array($_content)){
        foreach ($_content as $key=>$value){
            $_content[$key]=htmlspecialchars($value);
        }
    }else if(is_object($_content)){
        foreach ($_content as $key=>$value){
            $_content->$key=htmlspecialchars($value);
        }
    }else{
        echo "filter()参数类型错误！";
    }
    return $_content;
}
/**
 * 反过滤：恢复到过滤前的字符串、数组、对象
 *
 * @param mixed $_content  
 * @return mixed;
 * */
public static function filter_decode($_content){
    if(is_string($_content)){
        $_content=htmlspecialchars_decode($_content);
    }else if(is_array($_content)){
        foreach ($_content as $key=>$value){
            $_content[$key]=htmlspecialchars_decode($value);
        }
    }else if(is_object($_content)){
        foreach ($_content as $key=>$value){
            $_content->$key=htmlspecialchars_decode($value);
        }
    }else{
        echo "filter()参数类型错误！";
    }
    return $_content;
}
/**
 * 修剪字符串
 * 如果字符串长度超过要修剪的值得话，默认会显示省略号。
 * @param string $_string：要修剪的字符串
 * @param int $_length：指定修剪的长度
 * @param string $_suffix：字符串后缀
 * @param number $_start：修剪字符串开始的索引值  */
public static function substring($_string,$_length,$_suffix='...',$_start=0){
    //字符串的长度
    $num=mb_strlen($_string);
    //字符串有值;
    if($_start<$num-1){
        //当指定的长度大于字符串的长度时
        if($num<$_length){
            return mb_substr($_string, $_start,$_length,"utf8");
            //当指定的长度小于字符串的长度时
        }else{
            return mb_substr($_string, $_start,$_length,"utf8").$_suffix;
        }
    }else if($_start==($num-1)){
        echo "";
    }
}
    public static function dump($_content){
        echo "<pre>";
        var_dump($_content);
        echo "</pre>";
    }
    
}

//Tools::Redirect("测试成功","http://www.taobao.com",0);
//Tools::dump("peter");
/* $member=array("username"=>"mary");
$t=new Tools();
echo $t->dump($member); */
?>
<?php 
$str="<h1 style='font-size:999px'>hello</h1>";
$member=array(
    "username"=>"<h1 style='font-size:999px'>hello</h1>",
    "gender"=>"<h3>Female</h3>"
);
class Demo{
    public $usernme="<h1 style='font-size:999px'>hello</h1>";
}
$d=new Demo();
//unset($_SESSION['username']);
//$_SESSION['username']="tom";
//$_SESSION['level']="111";
unset($_SESSION['username']);
//session_destroy();
Tools::dump($_SESSION);
//echo Tools::filter($str);
//Tools::dump($member);
//Tools::dump(Tools::filter_decode(Tools::filter($d)));
if(Tools::hasSession('username')){
    echo "未登录";
}else{
    echo $_SESSION['username']."登录";
}

//echo mb_strlen("上海","utf8");
//echo mb_substr("上阿斯顿发斯蒂芬阿斯蒂芬阿斯蒂芬阿萨德",0,4);
//Tools::dump($_SERVER["REQUEST_URI"]);
?>











