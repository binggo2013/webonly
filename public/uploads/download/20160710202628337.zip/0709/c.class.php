<?php
class c{
    public $add=65621;
}
?>