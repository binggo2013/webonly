<?php
include 'Tools.php';
class member{
    public $usrename="tom";
    public $color;
    const host="127.1.1.1";
    public static $num=0;
    public function __construct($_color){
        //echo "我是php独特的构造方法";
        $this->color=$_color;
    }
    public function add(){
        return self::$num++;
    }
    /* public function member(){
        echo "我是member<br>";
    } */
    public function getColor(){
        return $this->color."<br>";
    }
    public function demo(){
        echo "我是demo<br>";
    }
}
$m=new member("green");
echo $m->getColor();
echo $m->usrename."<br>";
$m->demo();
echo member::host."<br>";
echo $m->add();
echo $m->add();
$n=new member();
echo $n->add();
echo $n->usrename;
//dump($m);
?>