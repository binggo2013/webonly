<?php
include 'Tools.php';
try{
    //尝试执行的代码
    $pdo=new PDO("mysql:host=localhost;dbname=kong","root","");
}catch (PDOException $e){
    //捕获异常
    echo $e->getMessage();
}finally {
    //始终执行;
    echo "hello<br>";
}
$pdo->query("set names utf8");
//$sql="insert into user(username,email,regTime)values(?,?,now())";
$sql="insert into user(username,email,regTime)values(:username,:email,now())";
//执行预处理,返回sql语句对象
$statement=$pdo->prepare($sql);
$username="stanLee";
$email="stanLee@ashley.com";
//$statement->bindValue(":username","ttt");
//$statement->bindValue(":email","ttt@ttt.com");
//$statement->bindColumn("username",$username);
//$statement->bindColumn("email",$email);
$statement->bindParam(":username",$username);
$statement->bindParam(":email",$email);
//$statement->bindParam(1,$username);
//$statement->bindParam(2,$email);
//echo $pdo->exec($sql);
dump($statement->execute());
//dump($pdo->exec("update user set username='Independence Day' where id=20 and id=21;"));
//echo $pdo->exec("update user set username='Independence Day' where id=20;");
//dump($pdo->query("update user set username='mary' where id=26"));
//dump($result);
//dump($result->fetch(PDO::FETCH_OBJ));
//dump(json_encode($result->fetch(PDO::FETCH_OBJ)));
//dump($result->fetchAll(PDO::FETCH_OBJ));
//echo $result->rowCount();
//dump($result->fetchObject());
?>