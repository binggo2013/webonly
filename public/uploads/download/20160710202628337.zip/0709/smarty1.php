<?php
include "Tools.php";
include 'libs/Smarty.class.php';
$smarty=new Smarty();
echo $smarty->template_dir[0];
//dump($smarty);
$smarty->assign("username","tom");
$member=array('username'=>"peter");
$smarty->assign("member",$member);
class Car{
    public $color="red";
}
$car=new Car();
$smarty->assign("car",$car);
$smarty->assign("num1",50);
$smarty->assign("num2",150);
$smarty->display("demo1.html");
?>


