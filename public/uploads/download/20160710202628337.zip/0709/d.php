<?php
//声明一个命名空间
namespace kong;
const username='kong';
function demo(){
    return "demo";
}
?>