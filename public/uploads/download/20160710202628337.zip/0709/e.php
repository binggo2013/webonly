<?php
namespace king;
const username='wang';
?>