<?php
include 'Tools.php';
//链接mysql服务器
$mysqli=new mysqli("localhost","root","","kong");
//跑错
if(mysqli_connect_errno()){
    exit("failed");
}
$mysqli->set_charset("utf8");
//关闭自动提交
$mysqli->autocommit(false);
$sql="update zhang set money=money-500 where id=1;
      update wang set money2=money+500 where id=1;";
//dump($mysqli->multi_query($sql));
if($mysqli->multi_query($sql)){
    echo "付款成功";
    //三元条件
    $first=$mysqli->affected_rows==1?true:false;
    //下一个结果集
    $mysqli->next_result();
    $second=$mysqli->affected_rows==1?true:false;
    if(!$second){
        echo "收款失败";
    }
    if($first && $second){
        //手动提交
        $mysqli->commit();
        echo "交易成功";
    }else{
        echo "交易失败";
        //回滚:恢复到交易前状态
        $mysqli->rollback();
    }
    $mysqli->autocommit(true);
    //关闭数据库链接
    $mysqli->close();
}else{
    echo "付款失败";
}
?>