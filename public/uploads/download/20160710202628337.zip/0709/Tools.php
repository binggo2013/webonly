<?php
/**
 * 打印变量信息
 * @param mixed $_content  */
function dump($_content){
    echo "<pre>";
    var_dump($_content);
    echo "</pre>";
}
/**
 * 重定向函数
 * @param string $_msg:要显示的信息
 * @param string $_url:要跳转的路径
 * @param number $_t:重定向需要的时间，默认是3秒钟;
 * @param number $_flag:成功或是失败的颜色,默认是成功  */
function Redirect($_msg,$_url,$_flag=1,$_t=3){
    if($_flag==1){
        $color="green;";
    }else if($_flag==0){
        $color="red;";
    }
    echo "<div id='Redirect' data-countdown=".$_t." data-url=".$_url.">";
    echo "<span style='color:".$color."'>".$_msg."</span>";
    echo "&nbsp;<span id='timer'>".$_t."</span>";
    echo "</div>";
}
?>