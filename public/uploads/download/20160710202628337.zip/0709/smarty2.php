<?php
include "Tools.php";
include 'libs/Smarty.class.php';
$smarty=new Smarty();
try{
    //尝试执行的代码
    $pdo=new PDO("mysql:host=localhost;dbname=kong","root","");
}catch (PDOException $e){
    //捕获异常
    echo $e->getMessage();
}finally {
    //始终执行;
    //echo "hello<br>";
}
$pdo->query("set names utf8");
$result=$pdo->query("select * from user");
$data=$result->fetchAll(PDO::FETCH_OBJ);
$smarty->assign("data",$data);
//dump($data);
$smarty->display("demo2.html");
?>


