<?php
//echo dirname(__FILE__);
//声明一个常量
define("ROOT_PATH", dirname(__FILE__));
//echo ROOT_PATH;
include ROOT_PATH."/libs/Smarty.class.php";
//define("ROOT",$_SERVER['HTTP_HOST']."");
$smarty=new Smarty();
//var_dump(dirname($_SERVER['REQUEST_URI']));
//定义新的模板目录
$smarty->template_dir=ROOT_PATH."/application/views";
$smarty->compile_dir=ROOT_PATH."/run";
//var_dump($smarty)
?>