<?php
/* Smarty version 3.1.29, created on 2016-07-10 03:57:32
  from "C:\xampp\htdocs\php2\0709\guestbook\application\views\home\ad.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5781ab8cefc234_11923968',
  'file_dependency' => 
  array (
    '3076f16568018fb77daf79a3dd90a61721d1c850' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php2\\0709\\guestbook\\application\\views\\home\\ad.html',
      1 => 1468115728,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5781ab8cefc234_11923968 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<?php echo '<script'; ?>
 src="../../../public/scripts/ad.js"><?php echo '</script'; ?>
>
<link href="../../../public/styles/ad.css" rel="stylesheet">
</head>
<body>
<?php echo @constant('ROOT');?>

<h1>AD</h1>
<img src="../../../public/images/1.png">
</body>
</html>
mc||v<?php }
}
