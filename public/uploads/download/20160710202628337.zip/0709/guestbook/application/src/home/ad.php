<?php
include '../../../Smarty.init.php';
$smarty->display("home/ad.html");
?>