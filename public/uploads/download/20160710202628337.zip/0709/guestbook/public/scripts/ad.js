window.addEventListener("load",function(){
	function foo(){
		
	}
	foo.prototype.color="red";
	foo.prototype.msg=function(){
		console.log("msg");
	}
	var f=new foo();
	console.dir(f);
	//console.dir(window);
});