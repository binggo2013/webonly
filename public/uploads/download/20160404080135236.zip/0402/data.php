<?php
sleep(3);
//echo "hello from php";
var_dump($_POST);
?>