/**
 * Created by Administrator on 16-4-3.
 */
//加载file system模块
var fs=require("fs");
//向外部文件写入内容
fs.writeFile("demo.txt","shanghai",function(error){
    if(error){
        throw "wrong";
    }else{
        console.log("ok");
    }
});