/**
 * Created by Administrator on 16-4-3.
 */
var mysql=require("mysql");
//console.log(mysql);
//调用mysql模块的createConnection方法
//rows:行，fields字段
//host:主机名；user：用户名；password：密码
//database:数据库名
var connection=mysql.createConnection({
    host:"127.0.0.1",
    user:"root",
    password:"",
    database:"only2"
});
//console.log(connection)
var sql="select * from user limit 5,5";
//执行sql语句，并把数据获取
connection.query(sql,function(error,rows,fields){
    if(error){
        console.log(error);
    }else{
        for(var i in rows){
            console.log(rows[i].username);
        }
    }
});
