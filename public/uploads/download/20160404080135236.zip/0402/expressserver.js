/**
 * Created by Administrator on 16-4-3.
 */
//加载express模块
var express=require("express");
//把express对象赋给app
var app=express();
//创建环境
app.get("/",function(_request,_response){
    _response.send("hello");
});
//端口3000
app.listen(3000);
//console.log(express);