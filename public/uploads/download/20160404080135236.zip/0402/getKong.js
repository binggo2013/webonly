/**
 * Created by Administrator on 16-4-3.
 */
var k=require("./Kong.js");
console.log(k.addZero(55));