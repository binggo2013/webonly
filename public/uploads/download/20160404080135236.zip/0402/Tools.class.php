<?php
/**
 * 工具类
 * final类，不能被继承,
 * 基于Bootstrap、tools.css、tools.js
 *  */
final class Tools{
	/**
     * 重定向方法
     * 
     * 基于Botstrap.css的样式，通过jquery实现倒计时和跳转
     * @param string $_msg:反馈信息
     * @param string $_url:跳转路径
     * @param number $_flag:成功或者失败的颜色
     * @param number $_t  */
    public static function Redirect($_msg,$_url,$_flag=1,$_t=3){
        if($_flag==1){
            $_color="green";
        }else if($_flag==2){
            $_color="red";
        }
        echo "<div class='redirect modal-content'>
                <div class='modal-header'>
                 <span class='modal-title' style='color:".$_color."'>".$_msg."</span>
                </div>
                <div class='modal-body'>
                    <dl>
                        <dd id='msg' duration=".$_t." url=".$_url.">
                            <div class='progress'>
  								<div class='progress-bar progress-bar-striped active'></div>
                            </div>
                        </dd>
                        <dd id='countdown'>1%</dd>
                    </dl>
                </div>
                <div class='modal-footer'>页面跳转中，请稍后.</div>
               </div>"; 
          }	
	/**
	 * 修剪字符串，如果有剩余字符就显示省略号。
	 * @param string $_str
	 * @param number $_length
	 * @param string $_suffix
	 * @param number $_start
	 * @return string  */
	public static function subString($_str,$_length,$_suffix="...",$_start=0){
		//mb_substr();修剪多字节的字符串;
		$num=mb_strlen($_str);
		//判断修剪字符的启示值与字符长度的关系;
		if($_start<($num-1)){
			if($num<$_length){
				return mb_substr($_str, $_start,$_length,"utf8");
			}else{
				return mb_substr($_str, $_start,$_length,"utf8").$_suffix;
			}		
		}elseif($_start==($num-1)){
			echo "";			
		}else{
			return "<span style='color:red'>开始的索引值大于字符串的长度</span>";
		}				
	}	
	/**
     * 返回过滤后的内容
     *
     * @param mixed $_data
     * @return mixed  */
    public static function filter($_data){
        if(is_string($_data)){
            $str=htmlspecialchars($_data);
        }else if(is_array($_data)){
            foreach ($_data as $key=>$value){
                $str[$key]=htmlspecialchars($value);
            }
        }else if(is_object($_data)){
            foreach ($_data as $key=>$value){
                $str->$key=htmlspecialchars($value);
            }
        }else{
            exit("filter()参数传递错误");
        }
        return $str;
    }	
	/**
     * 反过滤
     *
     * @param mixed $_data
     * @return mixed  */
    public static function deFilter($_data){
        if(is_string($_data)){
            $str=htmlspecialchars_decode($_data);
        }else if(is_array($_data)){
            foreach ($_data as $key=>$value){
                $str[$key]=htmlspecialchars_decode($value);
            }
        }else if(is_object($_data)){
            foreach ($_data as $key=>$value){
                $str->$key=htmlspecialchars_decode($value);
            }
        }else{
            exit("filter()参数传递错误");
        }
        return $str;
    }
	/**
	 * 检测数据是否为空<br>
	 * 修剪掉空格后的字符长度为0；
	 * @param string $_data
	 * @return boolean  */
	public static function isNull($_data){
		if(mb_strlen(trim($_data),"utf8")==0){
			return true;
		}
		return false;
	}
	/**
	 * 检测数据是否是数字或数字类型的字符串
	 * @param number string number $_data
	 * @return boolean  */
	public static function isNumber($_data){
		if(!is_numeric($_data)){
			return true;
		}
		return false;
	}
	/**
	 * 检测两条数据是否相等
	 * @param string $_firstData
	 * @param string $_secondData
	 * @return boolean  */
	public static function isEqual($_firstData,$_secondData){
		if(trim($_firstData)!=trim($_secondData)){
			return true;
		}
		return false;
	}
	/**
     * 验证字符串的长度范围
     *
     * @param string $_data
     * @param int $_minLength:最小值
     * @param int $_maxLength：最大值;
     * @return boolean  不符合要求返回true*/
    public static function range($_data,$_minLength=6,$_maxLength=12){
        if(is_int($_minLength)&&is_int($_maxLength)&&$_minLength>0&&$_maxLength>0){
            if(mb_strlen(trim($_data),"utf8")<$_minLength||mb_strlen(trim($_data),"utf8")>$_maxLength){
                return true;
            }
        }else{
            exit("range()长度参数错误");
        }
        return false;
    }
	/**
	 * 验证邮箱
	 * @param string $_data
	 * @return boolean  */
	public static function isEmail($_data){		$pattern="/^[a-z0-9]([a-z0-9]*[-_\.]?[a-z0-9]+)*@([a-z0-9]+[-_]?[a-z0-9]+)+[\.][a-z]{2,4}([\.][a-z]{2})?$/i";
		if(!preg_match($pattern, $_data)){
			return true;
		}
		return false;
	}
	/**
	 * 检测session值是否存在
	 * @param string $_data
	 * @return boolean  */
	static public function isSession($_data){
		if(!isset($_SESSION[$_data])){
			return true;
		}
		return false;
	}
	/**
	 * 销毁session
	 * @param string $_data
	 * @return boolean  */
	public static function destroySession($_data){
		unset($_SESSION[$_data]);
		return true;
	}
	/**
     * 判断是否有权限
     *
     * @param string $_data:传进来的权限值;
     * @return boolean 没有权限，返回TRUE，有权限返回FALSE；
     * */
    public static function hasPermission($_data){
        if(!strstr($_SESSION['permission'],$_data)){
            return true;
        }
        return false;
    }
	/**
     * 输出变量simple description
     *
     * dump方法中传递的参数区分为字符串、数组、数字、对象、资源
     *
     * @method dump()：输出变量
     * @param mixed $_content：要输出的内容
     *  */
	static function dump($_content){
	    if($_content){
    	    		if(is_string($_content)){
                echo "<pre>";
                var_dump($_content);
                echo "</pre>";
            }else if(is_numeric($_content)){
                echo "<pre>";
                var_dump($_content);
                echo "</pre>";
            }else if(is_array($_content)){
                echo "<pre>";
                print_r($_content);
                echo "</pre>";
            }else if(is_object($_content)){
                echo "<pre>";
                var_dump($_content);
                echo "</pre>";
            }else if(is_resource($_content)){
                echo "<pre>";
                var_dump($_content);
                echo "</pre>";
            }else{
                exit("dump()参数不是字符串、数字、数组、对象、资源");
            }	        
	    }else{
	        echo "dump参数为空";
	    }		
	}
}
?>
