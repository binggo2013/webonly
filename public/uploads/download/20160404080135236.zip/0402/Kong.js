/**
 * Created by Administrator on 16-4-3.
 */
//自定义外部模块
exports.addZero=function(_num){
    if(_num>10){
        _num=""+_num;
    }else{
        _num="0"+_num;
    }
    return _num;
}