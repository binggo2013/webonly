/**
 * node.js服务器文件
 */
//加载http模块
var http=require("http");
//console.log(http);
//创建服务器
//listen:监听的端口
http.createServer(function(_reqeust,_response){
    _response.writeHead(200,{"Content-Type":"text/plain"});
    _response.end("hello world");
}).listen(1337,"127.0.0.1");
