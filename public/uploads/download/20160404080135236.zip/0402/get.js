/**
 * Created by Administrator on 16-4-3.
 */
//加载filesystem模块
var fs=require("fs");
//读取外部文件
fs.readFile("page1.php","utf8",function(error,data){
    if(error){
        console.log("读取外部文件出错");
    }else{
        console.log(data);
    }
});

