/**
 * 创建Kong对象
 * @constructor
 */
function Kong(){
    
}
/**
 * 为Kong对象添加$方法
 * @param _id
 * @returns {Element}
 */
Kong.prototype.$= function (_id) {
    return document.getElementById(_id);
}