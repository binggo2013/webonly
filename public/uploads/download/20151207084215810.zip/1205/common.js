/**
 * Created by Administrator on 15-11-1.
 */
function $(_id){
    return document.getElementById(_id);
}
/**
 * ΪС��10���������0
 * @return {string}
 * */
function addZero(_num){
    if(_num<10){
        _num="0"+_num;
    }else{
        _num=""+_num;
    }
    return _num;
}
/**
 * ��
 * */
function getWindowSize(){
    return {
        width:document.documentElement.clientWidth||window.innerWidth,
        height:document.documentElement.clientHeight||window.innerHeight
    }
}
/**
 * �
 * @todo ie8
 * */
function getScrollSize(){
    return {
        left:document.documentElement.scrollLeft||document.body.scrollLeft,
        top:document.documentElement.scrollTop||document.body.scrollTop
    }
}
/**
 * 根据元素的类名称选择元素
 * 循环所有的元素，符合指定类名称的元素追加到空数组中
 * 不符合的忽略。
 * */
function getElementsByClassName(_element,_className){
    var arr=[];
    for(var i=0;i<_element.length;i++){
        //如果元素的className等于传进来的_className
        if(_element[i].className==_className){
            arr.push(_element[i]);
        }else{
            continue;
        }
    }
    return arr;
}
/**
 * 多个页面多次执行window.onload
 * */
function addLoadEvent(func){
    var oldload=window.onload;
    if(typeof window.onload!='function'){
        window.onload=func;
    }else{
        window.onload=function(){
            oldload();
            func();
        }
    }
}
/**
 * 跨浏览器的事件绑定
 * @param _element {object}
 * @param _type {string}
 * @param _fn  {function}
 */
function addEventListener(_element,_type,_fn){
    //ie
    if(typeof _element.addEventListener=="undefined"){
        _element.attachEvent("on"+_type,_fn);
    }else{
        _element.addEventListener(_type,_fn,false);
    }
}
/**
 * 解除事件绑定
 * @param _element {object}
 * @param _type    {string}
 * @param _fn      {function}
 */
function removeEventListener(_element,_type,_fn){
    //ie
    if(typeof _element.removeEventListener=="undefined"){
        _element.detachEvent("on"+_type,_fn);
    }else{
        _element.removeEventListener(_type,_fn,false);
    }
}
/**
 * 跨浏览器的事件对象
 * @param _evt  {mixed}
 * @returns |Event}
 */
function handleEvent(_evt){
    return _evt=_evt||window.event;
}
/**
 * 获取事件发送者(Event Dispatch)
 * @param _evt
 * @returns {*}
 */
function getEventElement(_evt){
    if(window.event){
        _evt=_evt.srcElement;
    }else{
        _evt=_evt.target;
    }
    return _evt;
}
/**
 * 跨浏览起的阻止默认动作;
 * @param _evt
 */
function preventDefault(_evt){
    if(window.event){
        _evt=window.event;
        _evt.returnValue=false;
    }else{
        _evt.preventDefault();
    }
}
/**
 * 跨浏览器阻止事件冒泡
 * @param _evt
 */
function stopPropagation(_evt){
    if(window.event){
        _evt=window.event;
        //取消冒泡
        _evt.cancelBubble=true;
    }else{
        _evt.stopPropagation();
    }
}
/**
 * 获取鼠标的选择文本
 */
function getSelectionText(){
    var txt=null;
    //ff/chrome
    if(window.getSelection){
        txt=window.getSelection();
        //opara|safaria
    }else if(document.getSelection){
        txt=document.getSelection();
        //ie
    }else if(document.selection){
        txt=document.selection.createRange().text;
    }
    return txt;
}
/**
 * 检测邮编
 * @param _value
 * @returns {boolean}
 */
function checkZipcode(_value){
    pattern=/^[1-9][0-9]{5}$/;
    if(!pattern.test(_value)){
        return false;
    }else{
        return true;
    }
}
/**
 * 检测URL
 * @param _value
 * @returns {boolean}
 */
function checkURL(_value){
    //http://www.abc.com.cn
    pattern=/^(http|https):\/\/(www)\.([a-z]+)\.([a-z]{2,4})(\.[a-z]{2})?/gi;
    if(!pattern.test(_value)){
        return false;
    }else{
        return true;
    }
}
/**
 * 修剪字符串前后的空格
 * @param _value
 * @returns {XML|void|string|*}
 */
function trim(_value){
    var pattern=/^\s*(.+?)?\s*$/g;
    _value=_value.replace(pattern,"$1");
    return _value;
}
/**
 * 检测邮箱
 * @param _value
 * @returns {boolean}
 */
function checkEmail(_value){
    //kddddd@gmail.com.cn
    var pattern=/^[a-z0-9]+([\._-]+[a-z0-9]+)?@[a-z0-9]+([_-]+[a-z0-9]+)?\.[a-z]{2,4}(\.[a-z]{2,4})?$/i;
    if(!pattern.test(_value)){
        return false;
    }else{
        return true;
    }
}
/**
 * 跨浏览的创建XMLHttpRequest对象
 * @returns {*}
 */
function createXMLHttpRequest(){
    var xmlHttp;
    //ie
    if(window.ActiveXObject){
        xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
    }else{
        xmlHttp=new XMLHttpRequest();
    }
    return xmlHttp;
}