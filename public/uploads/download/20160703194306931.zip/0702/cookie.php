<?php
//echo time();
setcookie("username","tom",time()+60*60*24*7);
var_dump($_COOKIE);
echo $_COOKIE['username'];

?>