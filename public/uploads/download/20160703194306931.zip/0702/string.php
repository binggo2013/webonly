<?php
$num=55;
echo<<<EOT
33333;33$num.ADFADSFADF;
EOT;
echo $username."<br>";
echo<<<'EOT'
AAAAAAAAS$num.DFAASDFASDFASDF
EOT;
//$username="tom33";
//echo 'shanghai$username';
/* echo gettype($username)."<br>";
var_dump($username); */
?>