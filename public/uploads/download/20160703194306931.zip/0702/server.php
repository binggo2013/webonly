<?php
echo $_SERVER['HTTP_HOST']."<br>";
echo $_SERVER['HTTP_REFERER']."<br>";
echo $_SERVER['QUERY_STRING']."<br>";
echo "<pre>";
var_dump($_SERVER);
echo "</pre>";
?>