<script language="php">
echo "morning";
</script>
<?php
error_reporting(E_ALL^ E_NOTICE);
//$username="tom";
//echo "<h1>hello</h1>";
echo $username;
?>
<h1>world</h1>