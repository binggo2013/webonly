<?php
$member=array('a'=>"tom",'b'=>"peter",'c'=>"mary");
echo implode("#", $member)."<hr>";
$cityName="shanghai,beijing,chengdu";
var_dump(explode(",", $cityName));
echo "<hr>";
echo json_encode($member);
?>