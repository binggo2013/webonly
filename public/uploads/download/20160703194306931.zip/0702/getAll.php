<?php
header("Content-type: text/html; charset=utf-8");
//���ӷ�����
mysql_connect("127.0.0.1","root","") or die("wrong");
//ѡ�����ݿ�
mysql_select_db("kong")or die("database wrong");
$total=mysql_num_rows(mysql_query("select * from user"));
//echo $total;
//���ò������ݿ���ַ���
mysql_query("set names utf8");
$pagenum=3;
$pageTotal=ceil($total/$pagenum);
if(isset($_GET['page'])){
    $page=$_GET['page'];
    if($page<1){
        $page=1;
    }else if($page>$pageTotal){
        $page=$pageTotal;
    }
}else{
    $page=1;
}
//echo $pageTotal;
//$sql="select * from user  order by id desc limit ($page-1)*$pagenum,$pagenum";
$sql="select * from user order by id desc limit ".($page-1)*$pagenum." ,".$pagenum;
//$sql="select * from user order by id desc limit 0,5";
echo $sql;
//��ѯ��䷵�ص��ǽ����(��ʱ�ı�)
$result=mysql_query($sql);
//var_dump($result);
echo "<table border='1' width=95% align=center>";
echo "<tr><th>username</th><th>Email</th><th>time</th><th>Edit</th><th><a href='mysql_demo.php'>add</a></th></tr>";
//echo json_encode(mysql_fetch_array($result));
while($data=mysql_fetch_array($result)){
    echo"<tr>";
    echo "<td>".$data['username']."</td>";
    echo "<td>".$data['email']."</td>";
    echo "<td>".$data['regTime']."</td>"; 
    echo "<td>
        <a href='update.php?id=".$data['id']."'>update</a>
        |<a href='delete.php?id=".$data['id']."'>delete</a></td>";
    echo "<td></td>";
    echo"</tr>";
}
echo "</table>";
echo "<hr>";
echo "<ul>";
echo "<li><a href='?page=1'>First</a></li>";
echo "<li><a href='?page=".($page-1)."'>Prev</a></li>";
echo "<li><a href='?page=".($page+1)."'>Next</a></li>";
echo "<li><input type='text' value='".$page."' id='pageValue'></li>";
echo "<li><select id='pageSelect'>";
for($i=1;$i<=$pageTotal;$i++){
    //echo "<option>".$i;
    if($page==$i){
        echo "<option selected='selected'>".$i;
    }else{
        echo "<option>".$i;
    }
}
echo "</select></li>";
echo "<li><a href='?page=".$pageTotal."'>End</a></li>";
echo "<li><span class='page'>".$page."</span>/".$pageTotal."</li>";
echo "</ul>"
?>
<style>
#pageValue{
	border:1px solid #ddd;
	width:50px;
	text-align:center;
}
.page{
	color:red;
}
ul{
	list-style:none;
}
ul li {
	display:inline-block;
	margin-left:15px;
}
</style>
<script>
	var pageValue=document.getElementById("pageValue");
	var pageSelect=document.getElementById("pageSelect");
	pageSelect.addEventListener("change",function(){
		location.href="?page="+this.value;
	});
	//console.log(pageValue);
	pageValue.addEventListener("keyup",function(){
		//console.log(this.value);
		location.href="?page="+this.value;
	});
</script>