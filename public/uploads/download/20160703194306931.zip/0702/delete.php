<?php
include 'Tools.php';
error_reporting(E_ALL ^ E_NOTICE ^ E_STRICT ^ E_DEPRECATED);
//���ӷ�����
mysql_connect("127.0.0.1","root","") or die("wrong");
//ѡ�����ݿ�
mysql_select_db("kong")or die("database wrong");
//���ò������ݿ���ַ���
mysql_query("set names utf8");
if($_GET['id']){
    $sql="delete from user where id=".$_GET['id'];
    if(mysql_query($sql)){
        Redirect("删除数据成功","getAll.php",1);
    }else{
        echo "failed";
    }
}else{
   echo "id wrong"; 
}
?>
<link href='Tools.css' rel="stylesheet">
<script src='Tools.js'></script>
<script>
Redirect();
//console.log(Redirect.dataset.countdown);
</script>