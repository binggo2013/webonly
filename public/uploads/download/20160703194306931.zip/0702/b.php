<?php
//��ʼsession
session_start();
//var_dump($_POST);
if($_POST['send']){
    echo $_POST['username']."<a href='a.php'>jump</a>";
    $_SESSION['username']=$_POST['username'];
    var_dump($_SESSION);
}
?>
<form action="" method="post">
    <input type="text" name="username"><br>
    <input type="submit" name="send" value="Submit">
</form>