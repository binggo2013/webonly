<?php
echo __DIR__."<br>";
echo __FILE__."<br>";
echo __LINE__."<br>";
$member=array('username'=>"tom",'gender'=>"peter");
echo $member['username'];
?>