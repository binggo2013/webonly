<?php
echo "<pre>";
var_dump($_REQUEST);
echo "</pre>";
?>