<?php
include 'Tools.php';
error_reporting(E_ALL ^ E_NOTICE ^ E_STRICT ^ E_DEPRECATED);
//���ӷ�����
mysql_connect("127.0.0.1","root","") or die("wrong");
//ѡ�����ݿ�
mysql_select_db("kong")or die("database wrong");
//���ò������ݿ���ַ���
mysql_query("set names utf8");
//var_dump($_POST);
if($_POST['send']){
    //$_POST['username']="sarah";
    //$_POST['email']="sarah@tom.com";
    $sql="insert into user(
        username,
        email,
        regTime
    )values(
        '".$_POST['username']."',
        '".$_POST['email']."',
        now())";
    //echo $sql;
    //echo mysql_query($sql);
    if(mysql_query($sql)){
        //echo "<script>alert('added');location.href='getAll.php';</script>";
        Redirect("添加数据成功","getAll.php",1);
    }else{
        echo "FAILED";
    }
}
?>
<link href='Tools.css' rel="stylesheet">
<script src='Tools.js'></script>
<script>
Redirect();
//console.log(Redirect.dataset.countdown);
</script>
<form action="" method="post">
    <input type="text" name="username"><br>
    <input type="text" name="email"><br>
    <input type="submit" name="send" value='SUBMIT'><br>
</form>

