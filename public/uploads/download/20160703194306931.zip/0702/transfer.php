<?php
echo "<pre>";
var_dump($_POST);
var_dump($_FILES);
echo "</pre><br>";
echo $_FILES['pic']['name']."<br>";
echo $_FILES['pic']['error']."<br>";
echo $_FILES['pic']['tmp_name']."<br>";
echo $_FILES['pic']['size']."<br>";
echo $_FILES['pic']['type']."<br>";
move_uploaded_file($_FILES['pic']["tmp_name"], $_FILES['pic']["name"]);
echo "<img src='".$_FILES['pic']["name"]."'>";
?>