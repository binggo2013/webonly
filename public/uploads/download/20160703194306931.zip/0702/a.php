<?php
//��ʼsession
session_start();
if($_SESSION['username']){
    echo "welcome".$_SESSION['username']."<br>";
}else{
    echo "plz log in<a href='b.php'>jump</a>";
}
?>