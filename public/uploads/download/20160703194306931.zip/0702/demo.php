<?php
$str="0123456789abcdefghiljlmnopqrstuvwxyzABCDEFGHILJLMNOPQRSTUVWXYZ";
//echo strlen($str);
//���ɴ�д�ַ�
//echo strtoupper($str);
//echo $str[4];
//echo rand(1, 999);
$captcha=null;
for($i=0;$i<4;$i++){
    $captcha.=$str[rand(0,strlen($str)-1)];
}
echo $captcha;
?>