<?php
session_start();
$image=imagecreatetruecolor(100,50);
//����ͼƬ��ɫ
$bgColor=imagecolorallocate($image,200, 50,150);
imagefill($image,0, 0,$bgColor);
$fontColor=imagecolorallocate($image,255,255,255);
$str="0123456789abcdefghiljlmnopqrstuvwxyzABCDEFGHILJLMNOPQRSTUVWXYZ";
$captcha=null;
for($i=0;$i<4;$i++){
    $captcha.=$str[rand(0,strlen($str)-1)];
}
$_SESSION['captcha']=$captcha;
//imagestring($image,6, 20,20, "hello",$fontColor);
imagettftext($image,20, 0, 5, 30, $fontColor,"georgiab.ttf",$captcha);
imagepng($image);
?>