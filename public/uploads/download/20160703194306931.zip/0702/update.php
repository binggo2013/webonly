<?php
include 'Tools.php';
error_reporting(E_ALL ^ E_NOTICE ^ E_STRICT ^ E_DEPRECATED);
//���ӷ�����
mysql_connect("127.0.0.1","root","") or die("wrong");
//ѡ�����ݿ�
mysql_select_db("kong")or die("database wrong");
//���ò������ݿ���ַ���
mysql_query("set names utf8");
if($_GET['id']){
    //echo $_GET['id'];
    $sql="select * from user where id=".$_GET['id'];
    //mysql_query($sql):ִ�в�ѯ,���ؽ����;
    //mysql_fetch_array:�ӽ�����л�ȡ����
    $oneUser=mysql_fetch_array(mysql_query($sql));
    //var_dump($oneUser);
    //var_dump($_POST);
    if($_POST['send']){
        $sql="update    user
              set       username='".$_POST['username']."',
                        email='".$_POST['email']."'
              where     id=".$_GET['id'];
        //echo $sql;
        if(mysql_query($sql)){
            Redirect("修改数据成功","getAll.php",1);
        }else{
            echo "failed";
        }
    }
}else{
    echo "id wrong";
}
?>
<link href='Tools.css' rel="stylesheet">
<script src='Tools.js'></script>
<script>
Redirect();
//console.log(Redirect.dataset.countdown);
</script>
<form action="" method="post">
    <input type="text" name="username" value="<?php echo $oneUser['username'];?>"><br>
    <input type="text" name="email" value="<?php echo $oneUser['email'];?>"><br>
    <input type="submit" name="send" value='SUBMIT'><br>
</form>