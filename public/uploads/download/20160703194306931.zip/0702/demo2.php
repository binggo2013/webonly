<a href="server.php">jump</a>
<?php
//$member=array('level1'=>"tom",'level2'=>'peter','level3'=>'mary');
$member=array(0=>"tom",1=>'peter',2=>'mary');
echo "<pre>";
var_dump($member);
echo "</pre>";
echo $member['level2'];
//����һ������
$username="tom";
$gender="male";
echo $username.$gender."<hr>";
foreach ($member as  $key=>$value){
    echo $key.$value."<br>";
}
/* for($i=0;$i<count($member);$i++){
    echo $member[$i]."<br>";
} */
/*
 */
 function Sum($num1,$num2){
     return $num1+$num2;
 }
 /**
  * ����һ��Msg����
  * @param string $_msg:Ҫ���ݵ��ַ���
  * @author <h1>����</h1>
  * @return string  */
 function Msg($_msg){
     return $_msg;
 }
 echo Sum(10,5);
 echo Msg();
?>