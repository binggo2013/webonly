/**
 * Created by Administrator on 16-5-8.
 */
var ad=document.getElementById("ad");
console.log(ad);