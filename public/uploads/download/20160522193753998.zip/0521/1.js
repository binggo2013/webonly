/**
 * Created by Administrator on 16-5-22.
 */
var demo=document.getElementById("demo");
console.log(demo);
